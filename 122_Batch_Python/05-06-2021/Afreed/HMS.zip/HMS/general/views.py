from django.shortcuts import render

from django.views.generic import TemplateView
# Create your views here.
class HomePageView(TemplateView):
	template_name = 'index.html'

class AboutUsView(TemplateView):
	template_name = 'about_us.html'	

class ContactUsView(TemplateView):
	template_name = 'contact_us.html'