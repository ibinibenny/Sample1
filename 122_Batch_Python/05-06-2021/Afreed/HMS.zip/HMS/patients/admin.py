from django.contrib import admin

from patients.models import PatientsModel
# Register your models here.
admin.site.register(PatientsModel)