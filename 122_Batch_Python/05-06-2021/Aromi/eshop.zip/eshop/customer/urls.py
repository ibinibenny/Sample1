from django.conf.urls import url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings

from customer.views import CustomerRegister,CustomerListing,LoginView

from django.contrib.auth import views as auth_views

urlpatterns = [
    url(r'register/',CustomerRegister.as_view(),name='cust_reg'),
    url(r'custlist/',CustomerListing.as_view(),name='cust_list'),
    
    url(r'login/',LoginView.as_view(), name='login'),
    url(r'logout/',auth_views.LogoutView.as_view(), name='logout'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)