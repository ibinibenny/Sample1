from django import forms

from general.models import ContactModel,JobModel
	

class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','email','contact','message']



class JobCategoryForm(forms.ModelForm):
	class Meta:
		model = JobModel
		exclude = ('status','created_on')