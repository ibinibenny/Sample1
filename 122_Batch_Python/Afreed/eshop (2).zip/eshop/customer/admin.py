from django.contrib import admin

from customer.models import CustomerModel
# Register your models here.
admin.site.register(CustomerModel)