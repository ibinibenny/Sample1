from django.contrib import admin

from master.models import FeedbackModel
from master.models import Catagories
from master.models import BookCtagoryModel
# Register your models here.

admin.site.register(FeedbackModel)
admin.site.register(Catagories)
admin.site.register(BookCtagoryModel)