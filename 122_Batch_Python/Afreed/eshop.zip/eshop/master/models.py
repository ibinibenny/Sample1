from django.db import models

# Create your models here.

class FeedbackModel(models.Model):
	name = models.CharField(max_length=30)
	email = models.EmailField()
	contact = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)
	place = models.CharField(max_length=50,null=True,blank=True)

	def __str__(self):
		return self.name

class Catagories(models.Model):
	title = models.CharField(max_length=50)
	discription=models.TextField(max_length=500)		

class BookCtagoryModel(models.Model):
	title = models.CharField(max_length=50)
	cat_code = models.IntegerField(default=1010)
	discription=models.TextField(max_length=500)
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)
