from django.contrib import admin

from general.models import ContactUsModel
from general.models import GymItemModel
# Register your models here.

admin.site.register(ContactUsModel)
admin.site.register(GymItemModel)