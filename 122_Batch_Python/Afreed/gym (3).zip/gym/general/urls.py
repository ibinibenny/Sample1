from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings


from general.views import HomePageView,ContactUsView,AboutUsView,AdminPageView,TrainerPageView,GymItemView,GymItemlistView
from general.views import ItemDetailView,DeleteItemDetailView,UpdateItemView

urlpatterns = [
    path(r'home/',HomePageView.as_view(),name='index_page'),
    path(r'contactus/',ContactUsView.as_view(),name='contact_us_page'),
    path(r'aboutus/',AboutUsView.as_view(),name='about_us_page'),
    path(r'admin/',AdminPageView.as_view(),name='admin_page'),
    path(r'trainer/',TrainerPageView.as_view(),name='trainer_page'),
    path(r'gymitem/',GymItemView.as_view(),name='item_page'),
    path(r'listitem/',GymItemlistView.as_view(),name='item_list_page'),
    path(r'itemdetails/(?P<pk>[0-9]+)/$',ItemDetailView.as_view(),name='item_detail'),
    path(r'delete/(?P<pk>[0-9]+)/$',DeleteItemDetailView.as_view(),name='delete_detail'),
    path(r'<pk>/update/',UpdateItemView.as_view(),name='update_item'),

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)