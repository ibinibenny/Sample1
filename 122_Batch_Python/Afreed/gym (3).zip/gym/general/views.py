from django.core.files.base import File
from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,UpdateView
from general.models import ContactUsModel ,GymItemModel
from general.forms import ContactUsForm,GymItemForm

# Create your views here.
class HomePageView(TemplateView):
	template_name = 'index.html'

class SigninPageView(TemplateView):
	template_name = 'signin.html'

class ContactUsView(View):
	template_name = 'contact_us.html'
	form_class = ContactUsForm

	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactUsModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				phone_no = request.POST.get('phone_no'),
				message = request.POST.get('message')

				)	
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class AboutUsView(TemplateView):
	template_name = 'about_us.html'

class AdminPageView(TemplateView):
	template_name = 'admin.html'
	
class TrainerPageView(TemplateView):
	template_name = 'trainer.html'

class GymItemView(View):
	template_name = 'gym_item.html'
	form_class = GymItemForm

	def get(self,request):
		form = self.form_class()
		context = {
		'item_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			items = GymItemModel.objects.create(
				name = request.POST.get('name'),
				purpose = request.POST.get('purpose'),
				description = request.POST.get('description'),
				warranty = request.POST.get('warranty'),
				image = request.FILES.get('image')
				

				)
			return redirect('/general/listitem/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class  GymItemlistView(View):
	template_name = 'item_list.html'
	

	def get(self,request):
		item = GymItemModel.objects.all()
		context = {
		'gym' :item
		}
		return render(request,self.template_name,context)
				

class ItemDetailView(View):
	template_name = 'item_detail.html'	

	def get(self,request,pk):
		obj = GymItemModel.objects.get(id=pk)
		context = {
		'gym' :obj
		}
		return render(request,self.template_name,context)	

class DeleteItemDetailView(View):
	template_name = 'item_detail.html'

	def get(self,request,pk):
		itm_obj = GymItemModel.objects.get(id=pk).delete()
		obj_d = GymItemModel.objects.all()
		context = {
		'gym' :obj_d
		}
		#return render(request,self.template_name,context)	
		
		return redirect('/general/listitem/')

class UpdateItemView(UpdateView):
	template_name = 'update_item.html'
	fields = ['name','purpose','description','warranty','image']
	model = GymItemModel
	success_url = '/general/listitem/'
