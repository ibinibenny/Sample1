
from django.db import models

# Create your models here.
from django.contrib.auth.models import User



class CustomerModel(models.Model):
    basic_details = models.OneToOneField(User,on_delete=models.CASCADE)
    ROUTINE_CHOICES = (
    ('Beginer','Beginer-less than 6 months'),
    ('Intermediate','Intermediate-more than 6 months'),
    ('Advanced','Advanced-more than 3 years')    
    )
    routine = models.CharField(max_length=50,choices=ROUTINE_CHOICES)
    contact = models.CharField(max_length=30,null=True,blank=True)
    GENDER_CHOICES = (
    ('M', 'Male'),
    ('F', 'Female'),
    ('Others', 'Others')
    )
    gender =models.CharField(max_length=15,choices=GENDER_CHOICES)
    address = models.TextField(max_length=300,null=True,blank=True)
    pincode = models.IntegerField()
    place = models.CharField(max_length=30)
    created_on = models.DateField(auto_now=True)
    

