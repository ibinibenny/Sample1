from django.contrib import admin

from general.models import ContactUsModel
from general.models import GymItemModel
from general.models import CatagoryModel
# Register your models here.

admin.site.register(ContactUsModel)
admin.site.register(GymItemModel)
admin.site.register(CatagoryModel)