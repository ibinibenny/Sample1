from django import forms

from general.models import ContactUsModel,GymItemModel,CatagoryModel

class ContactUsForm(forms.ModelForm):
	class Meta:
		model = ContactUsModel
		fields = ['name','email','phone_no','message']

class GymItemForm(forms.ModelForm):
	class Meta:
		model = GymItemModel
		exclude = ('status','created_on',)	

class CatagoryForm(forms.ModelForm):
	class Meta:
		model = CatagoryModel
		exclude = ('status','created_on')