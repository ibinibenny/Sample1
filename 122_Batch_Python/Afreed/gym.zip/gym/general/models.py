from django.db import models

# Create your models here.
class ContactUsModel(models.Model):
	name = models.CharField(max_length=30)
	email = models.EmailField()
	phone_no = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)
	

	def __str__(self):
		return self.name

class CatagoryModel(models.Model):
	purpose = models.CharField(max_length=50)
	status = models.BooleanField(default=True)
	created_on = models.DateField(auto_now=True)

	def __str__(self):
		return self.purpose		

class GymItemModel(models.Model):
	purpose= models.ForeignKey(CatagoryModel,on_delete=models.CASCADE)
	#purpose_id=models.IntegerField()
	name = models.CharField(max_length=50)			
	description = models.TextField(max_length=500)
	warranty = models.IntegerField()
	image = models.ImageField(upload_to='media/')
	status = models.BooleanField(default=True)
	created_on = models.DateField(auto_now=True)

	def __str__(self):
		return self.name


