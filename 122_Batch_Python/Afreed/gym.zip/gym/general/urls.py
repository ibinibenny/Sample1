from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings


from general.views import HomePageView,ContactUsView,AboutUsView,AdminPageView,TrainerPageView,GymItemView,GymItemlistView
from general.views import ItemDetailView,DeleteItemDetailView,UpdateItemView
from general.views import CatagoryItemView,CatagoryListView,CatagoryDetailView,DeleteCatagoryView,UpdateCatagoryView

urlpatterns = [
    path(r'home/',HomePageView.as_view(),name='index_page'),
    path(r'contactus/',ContactUsView.as_view(),name='contact_us_page'),
    path(r'aboutus/',AboutUsView.as_view(),name='about_us_page'),
    path(r'admin/',AdminPageView.as_view(),name='admin_page'),
    path(r'trainer/',TrainerPageView.as_view(),name='trainer_page'),
    path(r'gymitem/',GymItemView.as_view(),name='item_page'),
    path(r'listitem/',GymItemlistView.as_view(),name='item_list_page'),
    path(r'itemdetails/(?P<pk>[0-9]+)/$',ItemDetailView.as_view(),name='item_detail'),
    path(r'delete/(?P<pk>[0-9]+)/$',DeleteItemDetailView.as_view(),name='delete_detail'),
    path(r'<pk>/update/',UpdateItemView.as_view(),name='update_item'),
    path(r'catagory/',CatagoryItemView.as_view(),name='catgry_page'),
    path(r'listcatagory/',CatagoryListView.as_view(),name='catgry_list'),
    path(r'catagorydetails/(?P<pk>[0-9]+)/$',CatagoryDetailView.as_view(),name='cat_detail'),
    path(r'catagorydelete/(?P<pk>[0-9]+)/$',DeleteCatagoryView.as_view(),name='delete_cat'),
    path(r'<pk>/updatecat/',UpdateCatagoryView.as_view(),name='update_cat'),

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)