from django.urls import path

from django.conf.urls.static import static
from django.conf import settings
from .views import gym_payments, payment_status
from payment.views import Paymentlist,Paymentlists

urlpatterns = [
    path('payment', gym_payments, name='payment'),
    path('payment-status', payment_status, name='payment-status'),
    path(r'paymentlist/',Paymentlist.as_view(),name='payment_list'),
    path(r'paymentlists/',Paymentlists.as_view(),name='payment_lists')

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

