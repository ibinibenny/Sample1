from django.shortcuts import render
from .forms import PaymentForm
import razorpay
from .models import Payment
from django.views.generic import View

def gym_payments(request):
    if request.method == "POST":
        name = request.POST.get('name')
        amount = int(request.POST.get('amount')) * 100

        # create Razorpay client
        client = razorpay.Client(auth=("rzp_test_5KGY0UQkIxBo4M", "saoYiFgrnVwCA0tptxUh2LjH"))

        # create order
        response_payment = client.order.create(dict(amount=amount,
                                                    currency='INR')
                                               )

        payment_id = response_payment['id']
        payment_status = response_payment['status']

        if payment_status == 'created':
            pay = Payment(
                name=name,
                amount=amount,
                payment_id=payment_id
            )
            pay.save()
            response_payment['name'] = name

            form = PaymentForm(request.POST or None)
            return render(request, 'payment.html', {'form': form, 'payment': response_payment})

    form = PaymentForm()
    return render(request, 'payment.html', {'form': form})


def payment_status(request):
    response = request.POST
    params_dict = {
        'razorpay_order_id': response['razorpay_order_id'],
        'razorpay_payment_id': response['razorpay_payment_id'],
        'razorpay_signature': response['razorpay_signature']
    }

    # client instance
    client = razorpay.Client(auth=("rzp_test_5KGY0UQkIxBo4M", "saoYiFgrnVwCA0tptxUh2LjH"))

    try:
        status = client.utility.verify_payment_signature(params_dict)
        payment = Payment.objects.get(payment_id=response['razorpay_order_id'])
        payment.razorpay_payment_id = response['razorpay_payment_id']
        payment.paid = True
        payment.save()
        return render(request, 'payment_status.html', {'status': True})
    except:
        return render(request, 'payment_status.html', {'status': False})


class Paymentlist(View):
	template_name = 'payment_list.html'

	def get(self,request):
		item = Payment.objects.all()
		context = {
		'cus_list' :item
		}
		return render(request,self.template_name,context) 

class Paymentlists(View):
	template_name = 'payment_list1.html'

	def get(self,request):
		item = Payment.objects.all()
		context = {
		'cus_list' :item
		}
		return render(request,self.template_name,context)         