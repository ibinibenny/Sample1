from django.contrib import admin

from trainer.models import TrainerModel
# Register your models here.
admin.site.register(TrainerModel)