from django.shortcuts import render,redirect

from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from trainer.models import TrainerModel
from customer.models import CustomerModel


from trainer.forms import UserForm,TrainerForm,LoginForm
from django.views.generic import FormView,View,UpdateView

# Create your views here.

class TrainerRegister(FormView):
    template_name ='trainer_reg.html'
    form_class = UserForm

    def get(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        trainer_form = TrainerForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=trainer_form))

    def post(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        trainer_form = TrainerForm(self.request.POST)
        if (user_form.is_valid() and trainer_form.is_valid()):
            return self.form_valid(user_form, trainer_form)
        else:
            return self.form_invalid(user_form, trainer_form)

    def form_valid(self,user_form,trainer_form):
        self.object = user_form.save() #User model save
        self.object.is_staff=True # edit user object
        self.object.save()
        cust_obj = trainer_form.save(commit=False) #Customer Model save(contact,address,place,pincode,gender)
        cust_obj.basic_details=self.object #saving OneToOnefield ,edit cust_obj
        cust_obj.save()
        return super(TrainerRegister, self).form_valid(user_form)

    def form_invalid(self,user_form,trainer_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=trainer_form))

    def get_success_url(self, **kwargs):
        return('/general/trainer/')  

class Trainerlist(View):
	template_name = 'trainer_list.html'

	def get(self,request):
		item = TrainerModel.objects.all()
		context = {
		'trainer_list' :item
		}
		return render(request,self.template_name,context)      

class DeleteTrainer(View):
	template_name = 'trainer_list.html'

	def get(self,request,pk):
		itm_obj = TrainerModel.objects.get(id=pk).delete()
		tairner_d = TrainerModel.objects.all()
		context = {
		'trainer_list' :tairner_d
		}
		#return render(request,self.template_name,context)	
		
		return redirect('/general/customerlist/')	       
        
class UpdateTrainer(UpdateView):
	template_name = 'trainer_update.html'
	fields = ['contact','gender','address','pincode' ,'place']
	model = TrainerModel
	success_url = '/general/trainerlist/'  

class LoginView(View):
    template_name = 'login.html'  
    form_class = LoginForm

    def get(self,request):
        form = LoginForm
        context = {
        'form' :form
        }
        return render(request,self.template_name,context)
    
    def post(self,request):
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            uname = request.user
            try:
                user_obj= User.objects.get(username=uname)
                cust = CustomerModel.objects.get(basic_details=user_obj)           
            except:
                user_obj=None    
                cust=None
                
            try:
                user_obj= User.objects.get(username=uname)
                tobj= TrainerModel.objects.get(basic_details=user_obj)

            except:
                user_obj=None  
                tobj= None     

            if request.user.is_superuser:
                return redirect('/general/admin/')
            elif cust:
                return redirect('/customer/cushome/')         
            elif tobj:
                return redirect('/general/trainer/')       
            else:
                return redirect('login')    

        else:
            return redirect('login')     

class Profile(View):
	template_name = 'user_profile.html'

	def get(self,request):
		loginid_username = request.user
		user_objj = User.objects.get(username=loginid_username)
		cust_objj = CustomerModel.objects.get(basic_details=user_objj)
		context = {
		'userr' :cust_objj
		}
		return render(request,self.template_name,context)