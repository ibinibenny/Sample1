from django.contrib import admin

from general.models import ContactUsModel,ProductCategoryModel
# Register your models here.

admin.site.register(ContactUsModel)
admin.site.register(ProductCategoryModel)