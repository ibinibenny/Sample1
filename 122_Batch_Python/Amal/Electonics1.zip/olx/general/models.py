

from django.db import models

# Create your models here.
class ContactUsModel(models.Model):
	name = models.CharField(max_length=35)
	email = models.EmailField()
	phone_no = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)

	def __str__(self):
		return self.name

class ProductCategoryModel(models.Model):
	title = models.CharField(max_length=30)
	category = models.CharField(max_length=30)
	description = models.TextField(max_length=500)
	cover_img = models.ImageField(upload_to='media/')
	price = models.IntegerField()
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.title
