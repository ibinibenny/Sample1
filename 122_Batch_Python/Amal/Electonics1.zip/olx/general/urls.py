from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from general.views import HomePageView,AboutUsView,ContactUsView,AdminPageView,ProductPageView,ListProductView,ProductDetailView,ProductDeleteView

urlpatterns = [
    path('home/',HomePageView.as_view(),name='index_page'),
    path('about/',AboutUsView.as_view(),name='about_page'),
    path('contact/',ContactUsView.as_view(),name='contact_page'),
    path('admin/',AdminPageView.as_view(),name='admin_page'),
    path('product/',ProductPageView.as_view(),name='product_page'),
	path('listproduct/',ListProductView.as_view(),name='product_list_page'),
    path('detailprdt/(?P<pk>[0-9]+)/$',ProductDetailView.as_view(),name='product_detail_page'),
    path('deleteprdt/',ProductDeleteView.as_view(),name='product_delete_page')
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)