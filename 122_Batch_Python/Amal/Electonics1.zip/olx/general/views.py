from django.shortcuts import render,redirect

from django.views.generic import TemplateView,View

from general.models import ContactUsModel,ProductCategoryModel

from general.forms import ContactUsForm,ProductForm


class HomePageView(TemplateView):
	template_name = 'index.html'

class AboutUsView(TemplateView):
	template_name ='about_us.html'	

class ContactUsView(View):
	template_name = 'contact_us.html'
	form_class = ContactUsForm

	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactUsModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				phone_no = request.POST.get('phone_no'),
				message = request.POST.get('message')

				)	
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class AdminPageView(TemplateView):
	template_name = 'admin.html'

class ProductPageView(View):
	template_name = 'product.html'
	form_class = ProductForm

	def get(self,request):
		form = self.form_class()
		context = {
		'product_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			prd = ProductCategoryModel.objects.create(
				title = request.POST.get('title'),
				category = request.POST.get('category'),
				description = request.POST.get('description'),
				cover_img = request.FILES.get('cover_img'),
				price = request.POST.get('price'),
				)
			return redirect('/general/about/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListProductView(View):
	template_name = 'product_list.html'
	def get(self,request):
		pro_list = ProductCategoryModel.objects.all()
		context = {
		'pro' :pro_list
		}
		return render(request,self.template_name,context)

class ProductDetailView(View):
	template_name = 'product_detail.html'

	def get(self,request,pk):
		obj = ProductCategoryModel.objects.get(id=pk)
		context = {
		'prd' :obj
		}
		return render(request,self.template_name,context)

class ProductDeleteView(View):
	template_name = 'product_list.html'
	def get(self,request,pk):
		cat_obj = ProductCategoryModel.objects.get(id=pk).delete()
		pro_list = ProductCategoryModel.objects.all()
		context = {
		'pro' :pro_list
		}
		return render(request,self.template_name,context)




