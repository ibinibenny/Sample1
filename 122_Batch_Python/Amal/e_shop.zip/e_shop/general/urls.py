from django.contrib import admin
from django.conf.urls import url
from general.views import HomepageView,About_usView

urlpatterns = [
    url('home/',HomepageView.as_view(),name='index_page'),
    url('about/',About_usView.as_view(),name='about us_page'),
   
]
