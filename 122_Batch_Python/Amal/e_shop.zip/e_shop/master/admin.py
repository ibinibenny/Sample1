# -*- coding: utf-8 -*-
from django.contrib import admin

from master.models import FeedbackModel  

from master.models import category

from master.models import BookCategoryModel

# Register your models here.

admin.site.register(FeedbackModel)
admin.site.register(category)
admin.site.register(BookCategoryModel)