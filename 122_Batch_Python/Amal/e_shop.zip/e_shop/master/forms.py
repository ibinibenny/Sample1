from django import forms

from master.models import FeedbackModel,category,BookCategoryModel

class FeedbackForm(forms.ModelForm):
	class Meta:
		model = FeedbackModel
		fields = ['name','email','contact','message','place']

class CategoryForm(forms.ModelForm):
	class Meta:
		model = category
		fields = ['title','description',]


class BookCategoryForm(forms.ModelForm):
	class Meta:
		model = BookCategoryModel
		exclude = ('status','created_on')

