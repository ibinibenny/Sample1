from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from master.views import CreateFeedbackView,listFeedbackView,createCategoryView,FeedbackDetailView,listCategoryView,CategorydetailsView

from master.views import NewBookCategoryView,UpdateCatagoriesView,ListBookCategoryView,BookCatgryDetailView,DeleteBookCatgryView
urlpatterns = [
	path('feedback/',CreateFeedbackView.as_view(),name='new_fdbk'),
	path('listfeeds/',listFeedbackView.as_view(),name='list_fdbk'),
	path('Category/',createCategoryView.as_view(),name='category_fdbk'),
	path(r'fdbckdetails/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(),name='fdbk_detail'),
	path('listcategory/',listCategoryView.as_view(),name='listcategory_fdbk'),
	path(r'categorydetails/(?P<pk>[0-9]+)/$',CategorydetailsView.as_view(),name='category_details'),
	path('bkcatgry/',NewBookCategoryView.as_view(),name='new_bk_catgry'),
	path(r'<pk>/update/',UpdateCatagoriesView.as_view(),name='update_cat'),
	path(r'listbkcatgry/',ListBookCategoryView.as_view(),name='list_bk'),
	path(r'bkcatgry/(?P<pk>[0-9]+)/$',BookCatgryDetailView.as_view(),name='bkcatgry_detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',DeleteBookCatgryView.as_view(),name='delete_bkcatgry_detail'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
