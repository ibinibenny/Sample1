from django.shortcuts import render,redirect
from django.views.generic import CreateView,ListView,DetailView,View,UpdateView,View
from master.models import FeedbackModel,category,BookCategoryModel
from master.forms import FeedbackForm,CategoryForm,BookCategoryForm

# Create your views here.
class CreateFeedbackView(CreateView):
	template_name = 'create_fdbk.html'
	model = FeedbackModel
	form_class = FeedbackForm
	success_url ='/general/home'

class listFeedbackView(ListView):
	template_name = 'list_fdbk.html'
	model = FeedbackModel
	context_object_name = 'feedbacks'

class createCategoryView(CreateView):
	template_name = 'category.html'
	model = category
	form_class = CategoryForm
	success_url ='/general/home'

class FeedbackDetailView(DetailView):
	template_name ='fdbk_details.html'
	model =FeedbackModel	


class listCategoryView(ListView):
	template_name = 'list_category.html'
	model = category
	context_object_name = 'catagories'

class CategorydetailsView(DetailView):
	template_name = 'category_details.html'
	model = category
		
class NewBookCategoryView(View):
	template_name = 'new_bkcatgry.html'
	form_class = BookCategoryForm

	def get(self,request):
		form= self.form_class()
		context={
		'cat_form':form
		}
		return render(request,self.template_name,context)
	
	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			book_cat = BookCategoryModel.objects.create(
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				cat_code = request.POST.get('cat_code')
				)
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class UpdateCatagoriesView(UpdateView):
	template_name = 'update_ctgry.html'
	fields = ['title','description']
	model = category
	success_url = '/general/home/'

class ListBookCategoryView(View):
	template_name = 'list_bkcatgry.html'

	def get(self,request):
		bk_catgry = BookCategoryModel.objects.all()
		context={
		'catgry':bk_catgry
		}
		return render(request,self.template_name,context)							

class BookCatgryDetailView(View):
	template_name = 'bk_catgry_details.html'

	def get(self,request,pk):
		obj = BookCategoryModel.objects.get(id=pk)
		context = {
		'catgry' :obj
		}
		return render(request,self.template_name,context)

class DeleteBookCatgryView(View):
	template_name = 'list_bkcatgry.html'

	def get(self,request,pk):
		cat_obj =BookCategoryModel.objects.get(id=pk).delete()
		bk_catgry = BookCategoryModel.objects.all()
		context={
		'catgry':bk_catgry
		}
		return render(request,self.template_name,context)							



