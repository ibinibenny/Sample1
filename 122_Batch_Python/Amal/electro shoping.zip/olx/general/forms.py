from django import forms

from general.models import ContactUsModel,ProductCategoryModel,ItemCategoryModel
class ContactUsForm(forms.ModelForm):
	class Meta:
		model = ContactUsModel
		fields = ['name','email','phone_no','message']

class ProductForm(forms.ModelForm):
	class Meta:
		model = ProductCategoryModel
		exclude = ('status','created_on')


class ItemForm(forms.ModelForm):
	class Meta:
		model = ItemCategoryModel
		exclude = ('status','created_on')


