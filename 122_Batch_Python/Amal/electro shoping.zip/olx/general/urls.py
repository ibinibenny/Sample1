from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from general.views import HomePageView,AboutUsView,ContactUsView,AdminPageView,ProductPageView,ListProductView,ProductDetailView,ProductDeleteView,UpdateProductsView,CatagoryItemView
from general.views import ListItemView,ItemDetailView,DeleteItemView,UpdateitemView

urlpatterns = [
    path('home/',HomePageView.as_view(),name='index_page'),
    path('about/',AboutUsView.as_view(),name='about_page'),
    path('contact/',ContactUsView.as_view(),name='contact_page'),
    path('admin/',AdminPageView.as_view(),name='admin_page'),
    path('product/',ProductPageView.as_view(),name='product_page'),
	path('listproduct/',ListProductView.as_view(),name='product_list_page'),
    path('detailproduct/(?P<pk>[0-9]+)/$',ProductDetailView.as_view(),name='product_detail_page'),
    path('deleteprdt/(?P<pk>[0-9]+)/$',ProductDeleteView.as_view(),name='product_delete_page'),
    path(r'<pk>/update/',UpdateProductsView.as_view(),name='update_cat'),
    path('itemview/',CatagoryItemView.as_view(),name='item_page'),
    path('listitem/',ListItemView.as_view(),name='item_list_page'),
    path('detailitem/(?P<pk>[0-9]+)/$',ItemDetailView.as_view(),name='item_detail_page'),
    path('deleteitem/(?P<pk>[0-9]+)/$',DeleteItemView.as_view(),name='item_delete_page'),
    path(r'<pk>/updatecat/',UpdateitemView.as_view(),name='update_itm'),

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)