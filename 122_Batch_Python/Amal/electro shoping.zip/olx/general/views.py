from django.shortcuts import render,redirect

from django.views.generic import TemplateView,View,UpdateView
	
from general.models import ContactUsModel,ProductCategoryModel,ItemCategoryModel

from general.forms import ContactUsForm,ProductForm,ItemForm


class HomePageView(TemplateView):
	template_name = 'index.html'

class AboutUsView(TemplateView):
	template_name ='about_us.html'	

class ContactUsView(View):
	template_name = 'contact_us.html'
	form_class = ContactUsForm

	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactUsModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				phone_no = request.POST.get('phone_no'),
				message = request.POST.get('message')

				)	
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class AdminPageView(TemplateView):
	template_name = 'admin.html'

class ProductPageView(View):
	template_name = 'product.html'
	form_class = ProductForm

	def get(self,request):
		form = self.form_class()
		context = {
		'product_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			cat_obj = ItemCategoryModel.objects.get(id=request.POST.get('category'))
			prd = ProductCategoryModel.objects.create(
				title = request.POST.get('title'),
				category = cat_obj,
				description = request.POST.get('description'),
				cover_img = request.FILES.get('cover_img'),
				price = request.POST.get('price')
				)
			return redirect('/general/listproduct/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListProductView(View):
	template_name = 'product_list.html'
	def get(self,request):
		pro_list = ProductCategoryModel.objects.all()
		context = {
		'pro' :pro_list
		}
		return render(request,self.template_name,context)

class ProductDetailView(View):
	template_name = 'product_detail.html'

	def get(self,request,pk):
		obj = ProductCategoryModel.objects.get(id=pk)
		context = {
		'pro' :obj
		}
		return render(request,self.template_name,context)

class ProductDeleteView(View):
	template_name = 'product_list.html'
	def get(self,request,pk):
		cat_obj = ProductCategoryModel.objects.get(id=pk).delete()
		pro_list = ProductCategoryModel.objects.all()
		context = {
		'pro' :pro_list
		}
		return render(request,self.template_name,context)


class UpdateProductsView(UpdateView):
	template_name = 'update_prdt.html'
	fields = ['title','description','price']
	model = ProductCategoryModel
	success_url = '/general/listproduct/'

class CatagoryItemView(View):
	template_name = 'item_cat.html'
	form_class = ItemForm

	def get(self,request):
		form = self.form_class()
		context = {
		'cat_form':form
		}
		return render(request,self.template_name,context)
	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			shop_cat = ItemCategoryModel.objects.create(
				category = request.POST.get('category'),
				

				)	
			return redirect('/general/listitem/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class ListItemView(View):
	template_name = 'item_list.html'
	def get(self,request):
		pro_list = ItemCategoryModel.objects.all()
		context = {
		'cat' :pro_list
		}
		return render(request,self.template_name,context)


class ItemDetailView(View):
	template_name = 'item_detail.html'

	def get(self,request,pk):
		obj = ItemCategoryModel.objects.get(id=pk)
		context = {
		'cat' :obj
		}
		return render(request,self.template_name,context)


class DeleteItemView(View):
	template_name = 'item_list.html'
	def get(self,request,pk):
		cat_obj = ItemCategoryModel.objects.get(id=pk).delete()
		pro_list = ItemCategoryModel.objects.all()
		context = {
		'cat' :pro_list
		}
		return render(request,self.template_name,context)

class UpdateitemView(UpdateView):
	template_name = 'update_item.html'
	fields = ['category','status']
	model = ItemCategoryModel
	success_url = '/general/detailitem/'
