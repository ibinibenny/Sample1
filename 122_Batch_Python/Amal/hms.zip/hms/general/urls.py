from django.contrib import admin
from django.urls import path
from general.views import HomepageView,About_usView,contact_usView
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path(r'home/',HomepageView.as_view(),name='index_page'),
    path(r'about/',About_usView.as_view(),name='about us_page'),
    path(r'contact/',contact_usView.as_view(),name='contact us_page'),
   
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
