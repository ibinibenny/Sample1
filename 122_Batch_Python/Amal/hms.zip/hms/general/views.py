from django.shortcuts import render
from django.views.generic import TemplateView

# Create your views here.
class HomepageView(TemplateView):
	template_name = 'home.html'
	
class About_usView(TemplateView):
	template_name = 'about_us.html'

class contact_usView(TemplateView):
	template_name = 'contact_us.html'	