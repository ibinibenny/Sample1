from django.contrib import admin

from general.models import ContactUsModel
# Register your models here.

admin.site.register(ContactUsModel)