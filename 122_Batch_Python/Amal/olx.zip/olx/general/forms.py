from django import forms

from general.models import ContactUsModel

class ContactUsForm(forms.ModelForm):
	class Meta:
		model = ContactUsModel
		fields = ['name','email','phone_no','message']
