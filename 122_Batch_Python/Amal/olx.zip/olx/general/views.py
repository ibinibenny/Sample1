from django.shortcuts import render,redirect

from django.views.generic import TemplateView,View

from general.models import ContactUsModel

from general.forms import ContactUsForm


class HomePageView(TemplateView):
	template_name = 'index.html'

class AboutUsView(TemplateView):
	template_name ='about_us.html'	

class ContactUsView(View):
	template_name = 'contact_us.html'
	form_class = ContactUsForm

	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactUsModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				phone_no = request.POST.get('phone_no'),
				message = request.POST.get('message')

				)	
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})		