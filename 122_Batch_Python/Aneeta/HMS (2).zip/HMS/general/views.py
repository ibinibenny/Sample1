from django.shortcuts import render

# Create your views here.
from django.views.generic import TemplateView
class HomePageView(TemplateView):
	template_name='index.html'
class AboutUsView(TemplateView):
	template_name='aboutus.html'
class ContactUsView(TemplateView):
	template_name='contactus.html'