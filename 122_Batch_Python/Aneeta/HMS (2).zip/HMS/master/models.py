from django.db import models

# Create your models here.
class DepartmentModel(models.Model):
	title = models.CharField(max_length=25)
	description = models.TextField(max_length=500)
	hod = models.CharField(max_length=25)
	email = models.EmailField()
	contact = models.CharField(max_length=30,null=True,blank=True)
	status = models.BooleanField(default=True)
	created_on= models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.title