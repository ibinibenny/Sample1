from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from patients.views import PatientsRegister,Patientslist,DeletePatients

from django.contrib.auth import views as auth_views

urlpatterns = [
    path(r'register/',PatientsRegister.as_view(),name='pat_reg'),
    path(r'patientslist/',Patientslist.as_view(),name='pat_list'), 
    path(r'delete/(?P<pk>[0-9]+)/$',DeletePatients.as_view(),name='delete_pat'),
    path(r'login/', auth_views.LoginView.as_view(template_name="login.html"), name='login'),
    path(r'logout/', auth_views.LogoutView.as_view(), name='logout'), 

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)