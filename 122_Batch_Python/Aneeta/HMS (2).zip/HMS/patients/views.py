from django.shortcuts import render,redirect

from django.contrib.auth.models import User
from patients.models import PatientsModel

from patients.forms import UserForm,PatientsForm
from django.views.generic import FormView,View,UpdateView

# Create your views here.

class PatientsRegister(FormView):
    template_name ='patients_reg.html'
    form_class = UserForm

    def get(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        pat_form = PatientsForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=pat_form))

    def post(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        pat_form = PatientsForm(self.request.POST)
        if (user_form.is_valid() and pat_form.is_valid()):
            return self.form_valid(user_form, pat_form)
        else:
            return self.form_invalid(user_form, pat_form)

    def form_valid(self,user_form,pat_form):
        self.object = user_form.save() #User model save
        self.object.is_staff=True # edit user object
        self.object.save()
        pat_obj = pat_form.save(commit=False) #Customer Model save(contact,address,place,pincode,gender)
        pat_obj.basic_details=self.object #saving OneToOnefield ,edit cust_obj
        pat_obj.save()
        return super(PatientsRegister, self).form_valid(user_form)

    def form_invalid(self,user_form,pat_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=pat_form))

    def get_success_url(self, **kwargs):
        return('/gen/home/')  

class Patientslist(View):
	template_name = 'patients_list.html'

	def get(self,request):
		item = PatientsModel.objects.all()
		context = {
		'pat_list' :item
		}
		return render(request,self.template_name,context)     

class DeletePatients(View):
	template_name = 'patients_list.html'

	def get(self,request,pk):
		itm_obj = PatientsModel.objects.get(id=pk).delete()
		pat_d = PatientsModel.objects.all()
		context = {
		'pat_list' :pat_d
		}
		#return render(request,self.template_name,context)	
		
		return redirect('/general/patientslist/')	       
        
    