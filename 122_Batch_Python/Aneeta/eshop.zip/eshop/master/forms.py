from django import forms

from master.models import FeedbackModel
from master.models import CategoryModel,BookCategoryModel


class FeedbackForm(forms.ModelForm):
	class Meta:
		model=FeedbackModel
		fields=['name','email','contact','message','place']
class CategoryForm(forms.ModelForm):
	class  Meta:
		model=CategoryModel
		fields=['title','description']


class BookCategoryForm(forms.ModelForm):
	class Meta:
		model = BookCategoryModel
		exclude = ('status','created_on')
			
			
		