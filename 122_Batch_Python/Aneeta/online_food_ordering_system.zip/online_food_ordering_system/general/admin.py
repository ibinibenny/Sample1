from django.contrib import admin

from general.models import ContactModel

# Register your models here.
admin.site.register(ContactModel)
