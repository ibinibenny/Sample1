from django import forms

from general.models import ContactModel


class ContactForm(forms.ModelForm):
	class Meta:
		model=ContactModel
		fields=['name','email','contact','message']