from django import forms

from general.models import ContactModel,FoodCategoryModel


class ContactForm(forms.ModelForm):
	class Meta:
		model=ContactModel
		fields=['name','email','contact','message']
class FoodForm(forms.ModelForm):
	class Meta:
		model=FoodCategoryModel
		exclude = ('status','created_on')