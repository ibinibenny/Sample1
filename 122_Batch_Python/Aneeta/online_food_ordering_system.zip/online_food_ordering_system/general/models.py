from django.db import models

# Create your models here.
class ContactModel(models.Model):
	name = models.CharField(max_length=25)
	email = models.EmailField()
	contact = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)

	def __str__(self):
		return self.name

class FoodCategoryModel(models.Model):
	title =  models.CharField(max_length=30)
	description = models.TextField(max_length=600)
	status = models.BooleanField(default=True)
	food_category = models.CharField(max_length=30)
	price = models.IntegerField()
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.title

	

	