from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from general.views import HomePageView,ContactUsView,ContactSucessView,AboutUsView,AdminPageView,FoodPageView,ListFoodView,FoodDetailView,FoodDeleteView,FoodUpdateView
urlpatterns = [
	path('index/',HomePageView.as_view(),name='index_page'),
	path('contact/',ContactUsView.as_view(),name='contact_page'),
	path('contactsucess/',ContactSucessView.as_view(),name='contact_s_page'),
	path('aboutus/',AboutUsView.as_view(),name='about_us_page'),
	path('admin/',AdminPageView.as_view(),name='admin_page'),
	path('food/',FoodPageView.as_view(),name='food_page'),
	path('listfood',ListFoodView.as_view(),name='food_list_page'),
	path(r'fooddetail/(?P<pk>[0-9]+)/$',FoodDetailView.as_view(),name='food_detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',FoodDeleteView.as_view(),name='delete_food'),
	path(r'<pk>/update/',FoodUpdateView.as_view(),name='new_update'),
	
	
	
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
