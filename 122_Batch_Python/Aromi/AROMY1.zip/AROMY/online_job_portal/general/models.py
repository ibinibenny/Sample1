# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class ContactModel(models.Model):
    name = models.CharField(max_length=25)
    email = models.EmailField()
    contact = models.CharField(max_length=30,null=True,blank=True)
    message = models.TextField(max_length=500)

    def __str__(self):
        return self.name

class CategoryModel(models.Model):
    category = models.CharField(max_length=25)
    status = models.BooleanField(default=True)
    created_on = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.category       




class JobCategoryModel(models.Model): 
    title = models.CharField(max_length=300)
    location = models.CharField(max_length=150)
    job_category = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
    job_qualification = models.CharField(max_length=500,null=True)
    job_experience = models.CharField(max_length=30)
    job_description = models.CharField(max_length=200)
    salary = models.IntegerField(default=0, blank=True)     
    company_name = models.CharField(max_length=100)
    company_description = models.CharField(max_length=200)
    created_on = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title










