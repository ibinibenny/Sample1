from django.contrib import admin

from master.models import FeedbackModel
from master.models import Catagories
from master.models import BookCatgoryModel
# Register your models here.

admin.site.register(FeedbackModel)
admin.site.register(Catagories)
admin.site.register(BookCatgoryModel)