from django import forms

from master.models import FeedbackModel,Catagories,BookCatgoryModel

class FeedbackForm(forms.ModelForm):
	class Meta:
		model = FeedbackModel
		fields=['name','email','contact','message' ,'place' ]

class CatagoriesForm(forms.ModelForm):
	class Meta:
		model = Catagories
		fields = ['title','discription']

class BookCatagoryForm(forms.ModelForm):
	class Meta:
		model = BookCatgoryModel
		#fields = ['title','cat_code','discription']
		exclude = ('status','created_on')
				