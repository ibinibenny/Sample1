from django.conf.urls import url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from general.views import HomePageView,ContactUsView,ContactSucessView,AboutUsView,AdminView,EmployeView


urlpatterns = [
    url('index/',HomePageView.as_view(),name='index_page'),
    url('contact/',ContactUsView.as_view(),name='contact_page'),
    url('contactsucess/',ContactSucessView.as_view(),name='contact_s_page'),
    url('aboutus/',AboutUsView.as_view(),name='about_us_page'),
    url('adminn/',AdminView.as_view(),name='admins_page'),
    url('employeer/',EmployeView.as_view(),name='emp_page')
    
    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


