# -*- coding: utf-8 -*-
from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,TemplateView,TemplateView
from general.models import ContactModel
from general.forms import ContactForm
# Create your views here.
class HomePageView(TemplateView):
	template_name='index.html'

class ContactUsView(View):
	template_name = 'contact2.html'
	form_class = ContactForm

	def get(self,request):
		form = self.form_class()
		context = {
		'conct_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			conct = ContactModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)
			return redirect('/general/contactsucess/')	
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})
class ContactSucessView(TemplateView):
	template_name = 'contactsuccess.html'
class AboutUsView(TemplateView):
	template_name = 'aboutus.html'				
