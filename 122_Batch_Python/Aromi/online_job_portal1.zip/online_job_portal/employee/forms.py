from django import forms

from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from employee.models import EmployeeModel

from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
	

class EmployeeForm(forms.ModelForm):
	class Meta:
		model = EmployeeModel
		fields = ['contact','gender','address','pincode','place']

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields =['first_name','last_name','email','username','password1','password2']

class LoginForm(AuthenticationForm):
	class Meta:
		model = User
		fields =['username','password']

