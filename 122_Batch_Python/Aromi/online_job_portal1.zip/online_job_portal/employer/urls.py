from django.conf.urls import url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings

from employer.views import EmployerRegister,EmployerListing,EmployerDeleteView,UpdateView,LoginView
from django.contrib.auth import views as auth_views
urlpatterns = [
    url(r'register/',EmployerRegister.as_view(),name='emp1_reg'),
    url(r'employerlist/',EmployerListing.as_view(),name='emp_list'),
    url(r'updatee/(?P<pk>[0-9]+)/$',UpdateView.as_view(),name='updatee_detailss'),
    url(r'deletee/(?P<pk>[0-9]+)/$',EmployerDeleteView.as_view(),name='deletee_detailss'),
    url(r'login/',LoginView.as_view(), name='emp_login'),
    url(r'logout/',auth_views.LogoutView.as_view(), name='emp_logout'),  
    

   
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)