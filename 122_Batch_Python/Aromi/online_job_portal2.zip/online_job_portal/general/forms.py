from django import forms

from general.models import ContactModel,JobCategoryModel,JobVacancyModel
	

class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','email','contact','message']
class JobForm(forms.ModelForm):
	class Meta:
		model=JobCategoryModel
		exclude=('created_on',)
class VacancyForm(forms.ModelForm): 
	class Meta:
		model = JobVacancyModel
		fields = ['job_title','job_type','job_qualification','experience','job_location','job_description','salary_range','company_name','company_description']

