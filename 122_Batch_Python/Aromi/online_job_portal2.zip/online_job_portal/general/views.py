# -*- coding: utf-8 -*-
from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,TemplateView,TemplateView,TemplateView,TemplateView,View,View,View,View,UpdateView,View,View
from general.models import ContactModel,JobCategoryModel,JobVacancyModel
from general.forms import ContactForm,JobForm,VacancyForm

# Create your views here.
class HomePageView(TemplateView):
	template_name='index.html'

class ContactUsView(View):
	template_name = 'contact2.html'
	form_class = ContactForm

	def get(self,request):
		form = self.form_class()
		context = {
		'conct_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			conct = ContactModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)
			return redirect('/general/contactsucess/')	
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})
class ContactSucessView(TemplateView):
	template_name = 'contactsuccess.html'
class AboutUsView(TemplateView):
	template_name = 'aboutus.html'	

class AdminView(TemplateView):
	template_name = 'admin1.html'

class EmployeView(TemplateView):
	template_name ='employeer.html'	



class EmployeeJobsListView(View):
	template_name = 'job1.html'
	form_class = JobForm
	
	def get(self,request):
		form = self.form_class()
		context = {
		'job_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			job_cat = JobCategoryModel.objects.create(
				title  = request.POST.get('title'),
				location = request.POST.get('location'),
				job_description = request.POST.get('job_description'),
				salary= request.POST.get('salary'),
				job_type= request.POST.get('job_type'),
				company_name= request.POST.get('company_name'),
				category= request.POST.get('category'),
				company_description= request.POST.get('company_description'),
				)
			return redirect('/general/aboutus/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class ListJobView(View):
	template_name ='job_list1.html'
	def get(self,request):
		job_list=JobCategoryModel.objects.all()
		context = {
		'job' : job_list
		}
		return render(request,self.template_name,context)

class JobDetailView(View):
	template_name = 'job_detail.html'

	def get(self,request,pk):
		obj = JobCategoryModel.objects.get(id=pk)
		context	= {
		'job' :obj
		}
		return render(request,self.template_name,context)
class JobDeleteView(View):
	template_name = 'job_list1.html'		
	def get(self,request,pk):
		cat_obj = JobCategoryModel.objects.get(id=pk).delete()
		job_list =JobCategoryModel.objects.all()
		context = {
		'job' : job_list
		}
		return render(request,self.template_name,context)

class JobUpdateView(UpdateView):
	template_name = 'updatejob.html'
	fields = ['title','location','job_description','salary','job_type','company_name','category','company_description','created_on']
	model = JobCategoryModel
	success_url = '/general/joblistt/'



class JobVacancyView(View):
	template_name = 'vacancy.html'
	form_class = VacancyForm
	
	def get(self,request):
		form = self.form_class()
		context = {
		'vacancy_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			job_vacancy = JobVacancyModel.objects.create(
				job_title  = request.POST.get('job_title'),
				job_type = request.POST.get('job_type '),
				job_qualification= request.POST.get('job_qualification'),
				experience = request.POST.get('experience'),
                job_location = request.POST.get('job_location '),
                job_description = request.POST.get('job_description'),
                salary_range= request.POST.get('salary_range'),
				company_name = request.POST.get('company_name'),
				company_description= request.POST.get('company_description'),
				)
			return redirect('/general/index/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class ListVacancyView(View):
	template_name ='vacancydetails.html'
	def get(self,request):
		job_list=JobVacancyModel.objects.all()
		context = {
		
		}
		return render(request,self.template_name,context)








	



    