from django.contrib import admin

from general.models import ContactModel,CategoryModel,JobCategoryModel,CandidateModel
# Register your models here.
admin.site.register(ContactModel)
admin.site.register(CategoryModel)
admin.site.register(JobCategoryModel)
admin.site.register(CandidateModel)

