from django.shortcuts import render

from django.contrib.auth.models import User
from employee.models import EmployeeModel

from employee.forms import UserForm,EmployeeForm
from django.views.generic import FormView,View

# Create your views here.

class EmployeeRegister(FormView):
    template_name ='employee_register.html'
    form_class = UserForm

    def get(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        emp_form = EmployeeForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=emp_form))

    def post(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        emp_form = EmployeeForm(self.request.POST)
        if (user_form.is_valid() and emp_form.is_valid()):
            return self.form_valid(user_form, emp_form)
        else:
            return self.form_invalid(user_form, emp_form)

    def form_valid(self,user_form,emp_form):
        self.object = user_form.save() #User model save
        self.object.is_staff=True # edit user object
        self.object.save()
        emp_obj = emp_form.save(commit=False) #Customer Model save(contact,address,place,pincode,gender)
        emp_obj.basic_details=self.object #saving OneToOnefield ,edit cust_obj
        emp_obj.save()
        return super(EmployeeRegister, self).form_valid(user_form)

    def form_invalid(self,user_form,emp_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=emp_form))

    def get_success_url(self, **kwargs):
        return('/general/index/')   

class EmployeeListing(View):
    template_name = 'employee_list.html'
    def get(self,request):
        bk_list= EmployeeModel.objects.all()
        context ={
        'empl' : bk_list
        }
        return render(request,self.template_name,context)          



