from django import forms

from django.contrib.auth.models import User
from employer.models import EmployerModel

from django.contrib.auth.forms import UserCreationForm
	

class EmployerForm(forms.ModelForm):
	class Meta:
		model = EmployerModel
		fields = ['contact','gender','address','pincode','place']

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields =['first_name','last_name','email','username','password1','password2']

