from django.conf.urls import url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from general.views import HomePageView,ContactUsView,ContactSucessView,AboutUsView,AdminView,EmployeView,EmployeeJobsListView,ListJobView,JobDetailView,JobDeleteView,UpdateView,CategoryView,ListCategoryView,CategoryDetailView,CateogryDeleteView

urlpatterns = [
    url('index/',HomePageView.as_view(),name='index_page'),
    url('contact/',ContactUsView.as_view(),name='contact_page'),
    url('contactsucess/',ContactSucessView.as_view(),name='contact_s_page'),
    url('aboutus/',AboutUsView.as_view(),name='about_us_page'),
    url('adminn/',AdminView.as_view(),name='admins_page'),
    url('employeer/',EmployeView.as_view(),name='emp_page'),
    url(r'category/',CategoryView.as_view(),name='catgry_page'),
    url(r'categorylist',ListCategoryView.as_view(),name='category_detail'),
    url(r'categorydetails/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='category_detail'),
    url(r'deletecat/(?P<pk>[0-9]+)/$',CateogryDeleteView.as_view(),name='delete_category'),
    url(r'jobcategry/',EmployeeJobsListView.as_view(),name='job_catgry_page'),
    url(r'joblist/',ListJobView.as_view(),name='job_list_page'),
    url(r'jobdetails/(?P<pk>[0-9]+)/$',JobDetailView.as_view(),name='job_detail'),
    url(r'delete/(?P<pk>[0-9]+)/$',JobDeleteView.as_view(),name='delete_details'),    
    url(r'update/(?P<pk>[0-9]+)/$',UpdateView.as_view(),name='update_item'),

    

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



    # url(r'jobcategry/',EmployeeJobsListView.as_view(),name='job_catgry_page'),
    # url(r'joblistt',ListJobView.as_view(),name='job_list_page'),
    # url(r'jobdetails/(?P<pk>[0-9]+)/$',JobDetailView.as_view(),name='job_detail'),
    # url(r'delete/(?P<pk>[0-9]+)/$',JobDeleteView.as_view(),name='delete_details'),
    # url(r'<pk>/update/',JobUpdateView.as_view(),name='new_update'),
    # url(r'vacancy/',JobVacancyView.as_view(),name='add_vacancy'),
    # url(r'vacancylist/',ListVacancyView.as_view(),name='list_vacancy'),
   
   
    
    


