from django.contrib import admin

from general.models import ContactModel
from general.models import CategoryModel
from general.models import BusCategoryModel
# Register your models here.
admin.site.register(ContactModel)
admin.site.register(BusCategoryModel)
admin.site.register(CategoryModel)
