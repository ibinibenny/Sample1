from django import forms

from general.models import ContactModel,BusCategoryModel



class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','email','contact','message']

class BusForm(forms.ModelForm):
	class Meta:
		model = BusCategoryModel
		exclude = ('status','created_on')
