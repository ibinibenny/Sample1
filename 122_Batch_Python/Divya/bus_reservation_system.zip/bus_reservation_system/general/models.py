from django.db import models

# Create your models here.
class ContactModel(models.Model):
	name = models.CharField(max_length=25)
	email = models.EmailField()
	contact = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)
	
	def __str__(self):
		return self.name

class CategoryModel(models.Model):
	route = models.CharField(max_length=30)
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.route
		
class BusCategoryModel(models.Model):
	bus_number = models.IntegerField()
	bus_name = models.CharField(max_length=30)
	bus_category = models.CharField(max_length=30)
	cover_img = models.ImageField(upload_to='media/')
	route = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
	description = models.TextField(max_length=500)
	cost = models.IntegerField()
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.bus_name



	