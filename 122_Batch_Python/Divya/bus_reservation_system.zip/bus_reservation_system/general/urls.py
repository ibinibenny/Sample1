from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from general.views import HomePageView,ContactUsView,ContactSucessView,AboutUsView,AdminPageView,BusPageView,ListBusView,DetailBusView,DeleteBusView


urlpatterns = [
	path('index/',HomePageView.as_view() , name='index_page'),
	path('contact/',ContactUsView.as_view(),name='contact_page'),
	path('contactsucess/',ContactSucessView.as_view(),name='contact_s_page'),
	path('aboutus/',AboutUsView.as_view(),name='about_us_page'),
	path('admin/',AdminPageView.as_view(),name='admin_page'),
	path('bus/',BusPageView.as_view(),name='bus_page'),
	path('listbus/',ListBusView.as_view(),name='bus_list_page'),
	path(r'detailbus/(?P<pk>[0-9]+)/$',DetailBusView.as_view(),name='bus_detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',DeleteBusView.as_view(),name='delete_bus'),
	
	

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	 urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	 urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


