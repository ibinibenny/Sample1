from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,TemplateView,TemplateView,TemplateView,View
from general.models import ContactModel,BusCategoryModel
from general.forms  import ContactForm,BusForm
# Create your views here.

class HomePageView(TemplateView):
	template_name = 'index.html'

class ContactUsView(View):
	template_name = 'contact2.html'
	form_class = ContactForm

	def get(self,request):
		form = self.form_class()
		context = {
		'conct_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			conct = ContactModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)
			return redirect('/general/contactsucess/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ContactSucessView(TemplateView):
	template_name =  'contactsuccess.html'
class AboutUsView(TemplateView):
	template_name = 'about_us.html'

class AdminPageView(TemplateView):
	template_name = 'admin.html'

class BusPageView(View):
	template_name = 'bus.html'
	form_class = BusForm

	def get(self,request):
		form = self.form_class()
		context = {
		'bus_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			bus = BusCategoryModel.objects.create(
				bus_number = request.POST.get('bus_number'),
				bus_name = request.POST.get('bus_name'),
				bus_type = request.POST.get('bus_type'),
				title = request.POST.get('title'),
				cover_img = request.FILES.get('cover_img'),
				route = request.POST.get('route'),
				description = request.POST.get('description'),
				cost = request.POST.get('cost'),
				)
			return redirect('/general/aboutus/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListBusView(View):
	template_name = 'bus_list.html'
	def get(self,request):
		bus_list = BusCategoryModel.objects.all()
		context = {
		'bus' :bus_list
		}
		return render(request,self.template_name,context)



