from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from user.models import UserModel

from user.forms  import UserForm,User1Form,LoginForm
from django.views.generic import FormView,View,UpdateView,TemplateView


# Create your views here.

class UserRegister(FormView):
	template_name = 'user_register.html'
	form_class = UserForm

	def get(self,request,*args,**kwargs):
		self.object=None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		user1_form = User1Form()
		return self.render_to_response(self.get_context_data(form1=user_form, form2=user1_form))

	def post(self,request,*args,**kwargs):
		self.object=None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		user1_form = User1Form(self.request.POST)
		if (user_form.is_valid() and user1_form.is_valid()):
			return self.form_valid(user_form, user1_form)
		else:
			return self.form_invalid(user_form, user1_form)

	def form_valid(self,user_form,user1_form):
		self.object = user_form.save() #User model save
		self.object.is_staff=True # edit user object
		self.object.save()
		cust_obj = user1_form.save(commit=False) #Customer Model save(contact,address,place,pincode,gender)
		cust_obj.basic_details=self.object #saving OneToOnefield ,edit cust_obj
		cust_obj.save()
		return super(UserRegister, self).form_valid(user_form)

	def form_invalid(self,user_form,user1_form):
		return self.render_to_response(self.get_context_data(form1=user_form,form2=user1_form))
	def get_success_url(self, **kwargs):
		return('/user/login/')

class UserList(View):
	template_name = 'user_list.html'
	def get(self,request):
		bk_list = UserModel.objects.all()
		context = {
		'use' :bk_list
		}
		return render(request,self.template_name,context)

class DeleteUser(View):
	template_name = 'user_list.html'
	def get(self,request,pk):
		cat_obj = UserModel.objects.get(id=pk).delete()
		bk_list = UserModel.objects.all()
		context = {
		'use' :bk_list
		}
		return render(request,self.template_name,context)

class UpdateUser(UpdateView):
    model = UserModel
    fields = ['basic_details','contact','gender','address','pincode','place']
    template_name = 'user_update.html'
    success_url = '/user/userlist/'

class LoginView(View):
	template_name = "login.html"
	form_class = LoginForm

	def get(self,request):
		form = LoginForm
		context ={
			'form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):

		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(request, username=username, password=password)
		if user is not None:
			# uname and passwords are verified, proceed login procedures
			login(request,user)
			uname = request.user
			try:
				user_obj = User.objects.get(username=uname)
				cust = UserModel.objects.get(basic_details=user_obj)
			except:
				user_obj=None
				cust=None
			if request.user.is_superuser:
				return redirect('/general/admin')
			elif cust:
				return redirect('/user/indexlogout')
			else:
				return redirect('/user/login')


		else:
			return redirect('/user/login')

class IndexLog(TemplateView):
	template_name = 'logoutindex.html'

