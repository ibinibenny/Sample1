from django.contrib import admin

from general.models import ContactModel
from general.models import CategoryModel
from general.models import BusCategoryModel
from general.models import BookModel
from general.models import BusScheduleModel
from general.models import BusseatModel
# Register your models here.
admin.site.register(ContactModel)
admin.site.register(BusCategoryModel)
admin.site.register(CategoryModel)
admin.site.register(BookModel)
admin.site.register(BusScheduleModel)
admin.site.register(BusseatModel)