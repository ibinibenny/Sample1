from django import forms

from general.models import ContactModel,CategoryModel,BusCategoryModel,BookModel,BusScheduleModel,BusseatModel



class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','email','contact','message']

class BusForm(forms.ModelForm):
	class Meta:
		model = BusCategoryModel
		exclude = ('status','created_on')

class CategoryForm(forms.ModelForm):
	class Meta:
		model = CategoryModel
		exclude = ('status','created_on')

class BookForm(forms.ModelForm):
	class Meta:
		model = BookModel
		fields = ['customername','bus_number','source','destination','cost','date','ticket_status']

class ScheduleForm(forms.ModelForm):
	class Meta:
		model = BusScheduleModel
		fields = ['bus_number','route','bus_schedule','bus_time']

class SeatForm(forms.ModelForm):
	class Meta:
		model = BusseatModel
		fields = ['seat_no','bus_name','route','seat_details','seat_count']



