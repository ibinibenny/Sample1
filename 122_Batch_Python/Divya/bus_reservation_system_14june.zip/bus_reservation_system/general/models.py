from django.db import models
from datetime import date


# Create your models here.
class ContactModel(models.Model):
	name = models.CharField(max_length=25)
	email = models.EmailField()
	contact = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)
	
	def __str__(self):
		return self.name

class CategoryModel(models.Model):
	route = models.CharField(max_length=30)
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.route
		
class BusCategoryModel(models.Model):
	bus_number = models.IntegerField()
	bus_name = models.CharField(max_length=30)
	bus_category = models.CharField(max_length=30)
	cover_img = models.ImageField(upload_to='media/')
	route = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
	description = models.TextField(max_length=500)
	cost = models.IntegerField()
	# time = models.CharField(max_length=30)
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.bus_name

class BookModel(models.Model):
	customername = models.CharField(max_length=30)
	bus_number = models.ForeignKey(BusCategoryModel,on_delete=models.CASCADE)
	source = models.CharField(max_length=30)
	destination = models.CharField(max_length=30)
	cost = models.IntegerField()
	date = models.DateField(("Date"),default=date.today)
	TICKET_CHOICES = (
		('book','Booked'),
		('cancel','Cancelled')
		) 
	ticket_status = models.CharField(max_length=15,choices=TICKET_CHOICES)

class BusScheduleModel(models.Model):
	bus_number = models.ForeignKey(BusCategoryModel,on_delete=models.CASCADE)
	route = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
	BUSSCHEDULE_CHOICES = (
		('mrng','Morning'),
		('noon','AfterNoon'),
		('evng','Evening')
		)
	bus_schedule = models.CharField(max_length=15,choices=BUSSCHEDULE_CHOICES)
	bus_time = models.CharField(max_length=30)
		
class BusseatModel(models.Model):
	seat_no = models.IntegerField()
	bus_name = models.ForeignKey(BusCategoryModel,on_delete=models.CASCADE)
	route = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
	SEAT_CHOICES = (
		('available','Available Seats'),
		('booked','Booked Seats'),
		('select','Selected Seats')
		)
	seat_details = models.CharField(max_length=30,choices=SEAT_CHOICES)
	seat_count = models.IntegerField()

	