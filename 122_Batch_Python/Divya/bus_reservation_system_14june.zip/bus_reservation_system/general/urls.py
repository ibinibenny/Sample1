from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from general.views import HomePageView,ContactUsView,ContactSucessView,AboutUsView,AdminPageView,BusPageView,ListBusView,DetailBusView,DeleteBusView,BusUpdateView,BusRouteView,ListRouteView,DetailRouteView,DeleteRouteView,FeedbackView,DeleteFeedbackView,DetailInfoView,BookBusView,BookUpdateView,ScheduleView,ListScheduleView,DeleteScheduleView,ScheduleUpdateView,SeatView,ListSeatView,DeleteSeatView,SeatUpdateView,SeatAvailView,ScheduleuserView


urlpatterns = [
	path(r'index/',HomePageView.as_view() , name='index_page'),
	path(r'contact/',ContactUsView.as_view(),name='contact_page'),
	path(r'contactsucess/',ContactSucessView.as_view(),name='contact_s_page'),
	path(r'aboutus/',AboutUsView.as_view(),name='about_us_page'),
	path(r'admin/',AdminPageView.as_view(),name='admin_page'),
	path(r'bus/',BusPageView.as_view(),name='bus_page'),
	path(r'listbus/',ListBusView.as_view(),name='bus_list_page'),
	path(r'detailbus/(?P<pk>[0-9]+)/$',DetailBusView.as_view(),name='bus_detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',DeleteBusView.as_view(),name='delete_bus'),
	path(r'<pk>/update/',BusUpdateView.as_view(),name='new_update'),
	path(r'bus1/',BusRouteView.as_view(),name='bus_route'),
	path(r'listroute/',ListRouteView.as_view(),name='list_route'),
	path(r'detailroute/(?P<pk>[0-9]+)/$',DetailRouteView.as_view(),name='route_detail'),
	path(r'deleteroute/(?P<pk>[0-9]+)/$',DeleteRouteView.as_view(),name='delete_route'),
	path(r'feedback/',FeedbackView.as_view(),name='user_feedback'),
	path(r'deletefeed/(?P<pk>[0-9]+)/$',DeleteFeedbackView.as_view(),name='delete_feed'),
	path(r'businfo/',DetailInfoView.as_view(),name='bus_info'),
	path(r'booking/',BookBusView.as_view(),name='bus_book'),
	path(r'<pk>/updatebook/',BookUpdateView.as_view(),name='book_update'),
	path(r'schedule/',ScheduleView.as_view(),name='bus_shdule'),
	path(r'listschedule/',ListScheduleView.as_view(),name='bus_list_schedule'),
	path(r'deleteschedule/(?P<pk>[0-9]+)/$',DeleteScheduleView.as_view(),name='delete_schedule'),
	path(r'<pk>/updateschedule/',ScheduleUpdateView.as_view(),name='schedule_update'),
	path(r'seat/',SeatView.as_view(),name='bus_seat'),
	path(r'listseat/',ListSeatView.as_view(),name='bus_list_seat'),
	path(r'deleteseat/(?P<pk>[0-9]+)/$',DeleteSeatView.as_view(),name='delete_seat'),
	path(r'<pk>/updateseat/',SeatUpdateView.as_view(),name='seat_update'),
	path(r'seatavail/',SeatAvailView.as_view(),name='bus_avail_seat'),
	path(r'sceduleuser/',ScheduleuserView.as_view(),name='bus_schedule_seat')






	

	

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	 urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	 urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


