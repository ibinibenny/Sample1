from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,TemplateView,TemplateView,TemplateView,View,UpdateView,View
from general.models import ContactModel,CategoryModel,BusCategoryModel,BookModel,BusScheduleModel,BusseatModel
from general.forms  import ContactForm,CategoryForm,BusForm,BookForm,ScheduleForm,SeatForm
# Create your views here.

class HomePageView(TemplateView):
	template_name = 'index.html'

class ContactUsView(View):
	template_name = 'contact2.html'
	form_class = ContactForm

	def get(self,request):
		form = self.form_class()
		context = {
		'conct_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			conct = ContactModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)
			return redirect('/general/contact/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ContactSucessView(TemplateView):
	template_name =  'contactsuccess.html'
class AboutUsView(TemplateView):
	template_name = 'about_us.html'

class AdminPageView(TemplateView):
	template_name = 'admin.html'

class BusPageView(View):
	template_name = 'bus.html'
	form_class = BusForm

	def get(self,request):
		form = self.form_class()
		context = {
		'bus_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			cat_obj = CategoryModel.objects.get(id=request.POST.get('route'))
			bus = BusCategoryModel.objects.create(
				bus_number = request.POST.get('bus_number'),
				bus_name = request.POST.get('bus_name'),
				bus_category = request.POST.get('bus_category'),
				cover_img = request.FILES.get('cover_img'),
				route = cat_obj,
				description = request.POST.get('description'),
				cost = request.POST.get('cost')
				)
			return redirect('/general/listbus/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListBusView(View):
	template_name = 'buscard.html'
	def get(self,request):
		bus_list = BusCategoryModel.objects.all()
		context = {
		'bus' :bus_list
		}
		return render(request,self.template_name,context)

class DetailBusView(View):
	template_name = 'bus_details.html'

	def get(self,request,pk):
		obj = BusCategoryModel.objects.get(id=pk)
		context = {
		'buss' :obj
		}
		return render(request,self.template_name,context)

class DeleteBusView(View):
	template_name = 'buscard.html'
	def get(self,request,pk):
		cat_obj = BusCategoryModel.objects.get(id=pk).delete()
		bus_list = BusCategoryModel.objects.all()
		context = {
		'bus' :bus_list
		}
		return render(request,self.template_name,context)

class BusUpdateView(UpdateView):
    model = BusCategoryModel
    fields = ['bus_number','bus_name','bus_category','cover_img','route','description','cost']
    template_name = 'updatebus.html'
    success_url = '/general/listbus/'

class BusRouteView(View):
	template_name = 'busroute.html'
	form_class = CategoryForm

	def get(self,request):
		form = self.form_class()
		context = {
		'bus1_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			bk_obj = CategoryModel.objects.create(
				route = request.POST.get('route'),
				)
			return redirect('/general/listroute/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListRouteView(View):
	template_name = 'listroute.html'
	def get(self,request):
		bus1_list = CategoryModel.objects.all()
		context = {
		'newbus' :bus1_list
		}
		return render(request,self.template_name,context)

class DetailRouteView(View):
	template_name = 'route_details.html'

	def get(self,request,pk):
		obj = CategoryModel.objects.get(id=pk)
		context = {
		'busss' :obj
		}
		return render(request,self.template_name,context)

class DeleteRouteView(View):
	template_name = 'listroute.html'
	def get(self,request,pk):
		cat_obj = CategoryModel.objects.get(id=pk).delete()
		bus1_list = CategoryModel.objects.all()
		context = {
		'newbus' :bus1_list
		}
		return render(request,self.template_name,context)

class FeedbackView(View):
	template_name = 'feedback.html'
	def get(self,request):
		feed_list = ContactModel.objects.all()
		context = {
		'feedbackk' :feed_list
		}
		return render(request,self.template_name,context)

class DeleteFeedbackView(View):
	template_name = 'feedback.html'
	def get(self,request,pk):
		cat_obj = ContactModel.objects.get(id=pk).delete()
		feed_list = ContactModel.objects.all()
		context = {
		'feedbackk' :feed_list
		}
		return render(request,self.template_name,context)

class DetailInfoView(View):
	template_name = 'businfo.html'

	def get(self,request):
		obj = BusCategoryModel.objects.all()
		context = {
		'buss' :obj
		}
		return render(request,self.template_name,context)

class BookBusView(View):
	template_name = 'book.html'
	form_class = BookForm

	def get(self,request):
		form = self.form_class()
		context = {
		'book_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			cat_obj = BusCategoryModel.objects.get(id=request.POST.get('bus_number'))
			bus = BookModel.objects.create(
				customername = request.POST.get('customername'),
				bus_number = cat_obj,
				source = request.POST.get('source'),
				destination = request.POST.get('destination'),
				cost = request.POST.get('cost'),
				ticket_status = request.POST.get('ticket_status')
				)
			return redirect('/general/seatavail/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class BookUpdateView(UpdateView):
    model = BookModel
    fields = ['customername','bus_number','source','destination','cost','ticket_status']
    template_name = 'updatebook.html'
    success_url = '/general/businfo/'

class ScheduleView(View):
	template_name = 'schedule.html'
	form_class = ScheduleForm

	def get(self,request):
		form = self.form_class()
		context = {
		'shdule_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			cat_obj = BusCategoryModel.objects.get(id=request.POST.get('bus_number'))
			catt_obj = CategoryModel.objects.get(id=request.POST.get('route')) 
			bus = BusScheduleModel.objects.create(
				bus_number = cat_obj,
				route = catt_obj,
				bus_schedule = request.POST.get('bus_schedule'),
				bus_time = request.POST.get('bus_time')
				)
			return redirect('/general/listschedule/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListScheduleView(View):
	template_name = 'listschedule.html'
	def get(self,request):
		scedle_list = BusScheduleModel.objects.all()
		context = {
		'schedulee' :scedle_list
		}
		return render(request,self.template_name,context)

class DeleteScheduleView(View):
	template_name = 'listschedule.html'
	def get(self,request,pk):
		cat_obj = BusScheduleModel.objects.get(id=pk).delete()
		scedle_list = BusScheduleModel.objects.all()
		context = {
		'schedulee' :scedle_list
		}
		return render(request,self.template_name,context)

class ScheduleUpdateView(UpdateView):
    model = BusScheduleModel
    fields = ['bus_number','route','bus_schedule','bus_time']
    template_name = 'updateschedule.html'
    success_url = '/general/listschedule/'

class SeatView(View):
	template_name = 'seat.html'
	form_class = SeatForm

	def get(self,request):
		form = self.form_class()
		context = {
		'seat_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			cat_obj = BusCategoryModel.objects.get(id=request.POST.get('bus_name'))
			catt_obj = CategoryModel.objects.get(id=request.POST.get('route')) 
			bus = BusseatModel.objects.create(
				seat_no = request.POST.get('seat_no'),
				bus_name = cat_obj,
				route = catt_obj,
				seat_details = request.POST.get('seat_details'),
				seat_count = request.POST.get('seat_count')
				)
			return redirect('/general/listseat/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListSeatView(View):
	template_name = 'listseat.html'
	def get(self,request):
		seat_list = BusseatModel.objects.all()
		context = {
		'seatt' :seat_list
		}
		return render(request,self.template_name,context)

class DeleteSeatView(View):
	template_name = 'listseat.html'
	def get(self,request,pk):
		cat_obj = BusseatModel.objects.get(id=pk).delete()
		seat_list = BusseatModel.objects.all()
		context = {
		'seatt' :seat_list
		}
		return render(request,self.template_name,context)

class SeatUpdateView(UpdateView):
    model = BusseatModel
    fields = ['seat_no','bus_name','route','seat_details','seat_count']
    template_name = 'updateseat.html'
    success_url = '/general/listseat/'


class SeatAvailView(TemplateView):
	template_name = 'seatavailability.html'

class ScheduleuserView(View):
	template_name = 'userschedule.html'
	def get(self,request):
		scedle_user_list = BusScheduleModel.objects.all()
		context = {
		'scheduleeuser' :scedle_user_list
		}
		return render(request,self.template_name,context)




