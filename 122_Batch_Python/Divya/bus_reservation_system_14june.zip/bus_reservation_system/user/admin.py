from django.contrib import admin
from user.models import UserModel

# Register your models here.

admin.site.register(UserModel)

