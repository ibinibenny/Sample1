from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from user.views import UserRegister,UserList,DeleteUser,UpdateUser,LoginView,IndexLog

from django.contrib.auth import views as auth_views




urlpatterns = [
	path(r'register/',UserRegister.as_view(),name='user_reg'),
	path(r'userlist/',UserList.as_view(),name='use_list'),
	path(r'delete/(?P<pk>[0-9]+)/$',DeleteUser.as_view(),name='delete_user'),
	path(r'<pk>/update/',UpdateUser.as_view(),name='user_update'),
	path(r'login/',LoginView.as_view(),name='login'),
	path(r'logout/', auth_views.LogoutView.as_view(), name='logout'),
	path(r'indexlogout/',IndexLog.as_view(),name='index_logout')
	
	
    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	 urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	 urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
