from django.contrib import admin

from master.models import FeedbackModel
from master.models import CategoryModel
from master.models import BookCategoryModel
from master.models import BooksModel
# Register your models here.
admin.site.register(FeedbackModel)
admin.site.register(CategoryModel)
admin.site.register(BookCategoryModel)
admin.site.register(BooksModel)