from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings


from general.views import HomePageView,AboutUsView
from master.views import CreateFeedbackView,ListFeedbackView,CategoryView,FeedbackDetailView,ListCategoryView,CategoryDetailView,NewBookCategoryView,CategoryUpdateView,ListBookCategoryView,BookCategoryView,DeleteBookCatgryView,AddBookView,ListBookView



urlpatterns = [
	path(r'feedback/',CreateFeedbackView.as_view(),name='new_fdbk'),
	path(r'listfeeds/',ListFeedbackView.as_view(),name='list_fdbk'),
	path(r'category/',CategoryView.as_view(),name='category_fdbk'),
	path(r'fdbckdetails/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(),name='fdbk_detail'),
	path(r'listcategory/',ListCategoryView.as_view(),name='list_category'),
	path(r'categorydetails/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='category_detail'),
	path(r'bkcatgry/',NewBookCategoryView.as_view(),name='new_bk_catgry'),
	path(r'<pk>/update/',CategoryUpdateView.as_view(),name='new_update'),
	path(r'listbkcatgry/',ListBookCategoryView.as_view(),name='list_bk'),
	path(r'bkcategory/(?P<pk>[0-9]+)/$',BookCategoryView.as_view(),name='bkcatgry_detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',DeleteBookCatgryView.as_view(),name='delete_bk_catgry'),
	path(r'newbook/',AddBookView.as_view(),name='new_book'),
	path(r'listbooks/',ListBookView.as_view(),name='list_book'),
	
    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	 urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	 urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



