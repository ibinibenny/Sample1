from django.shortcuts import render,redirect

from django.views.generic import CreateView,ListView,CreateView,DetailView,ListView,DetailView,View,UpdateView,View,View,View,View,View
from master.models import FeedbackModel
from master.forms  import FeedbackForm
from master.models import CategoryModel
from master.forms import CategoryForm
from master.models import BookCategoryModel
from master.forms import BookCategoryForm
from master.models import BooksModel
from master.forms import BookForm

# Create your views here.

class CreateFeedbackView(CreateView):
	template_name = 'create_feedback.html'
	model = FeedbackModel
	form_class = FeedbackForm
	success_url = '/gen/home/'

class ListFeedbackView(ListView):
	template_name = 'list_feedback.html'
	model = FeedbackModel
	context_object_name = 'feedbacks'

class  CategoryView(CreateView):
	template_name = 'category.html'
	model = CategoryModel
	form_class = CategoryForm
	success_url = '/gen/home/'
		

class FeedbackDetailView(DetailView):
	template_name = 'feedback_details.html'
	model = FeedbackModel

class ListCategoryView(ListView): 
	template_name = 'list_category.html'
	model = CategoryModel
	context_object_name = 'category'

class CategoryDetailView(DetailView):
	template_name = 'category_details.html'
	model = CategoryModel

class NewBookCategoryView(View):
	template_name = 'new_book_category.html'
	form_class = BookCategoryForm

	def get(self,request):
		form = self.form_class()
		context = {
		'cat_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			book_cat = BookCategoryModel.objects.create(
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				cat_code = request.POST.get('cat_code')
				)
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class CategoryUpdateView(UpdateView):
    model = CategoryModel
    fields = ['title','description']
    template_name = 'update_form.html'
    success_url = '/gen/home/'

class ListBookCategoryView(View):
	template_name = 'list_bk_catgry.html'
	def get(self,request):
		bk_catgry = BookCategoryModel.objects.all()
		context = {
		'catgry' :bk_catgry
		}
		return render(request,self.template_name,context)

class BookCategoryView(View):
	template_name = 'bk_catgry_details.html'

	def get(self,request,pk):
		obj = BookCategoryModel.objects.get(id=pk)
		context = {
		'catgry' :obj
		}
		return render(request,self.template_name,context)

class DeleteBookCatgryView(View):
	template_name = 'list_bk_catgry.html'
	def get(self,request,pk):
		cat_obj = BookCategoryModel.objects.get(id=pk).delete()
		bk_catgry = BookCategoryModel.objects.all()
		context = {
		'catgry' :bk_catgry
		}
		return render(request,self.template_name,context)

class AddBookView(View):
	template_name = 'add_books.html'
	form_class = BookForm

	def get(self,request):
		form = self.form_class()
		context = {
		'book_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			cat_obj = BookCategoryModel.objects.get(id=request.POST.get('bk_catgry'))
			bk_obj = BooksModel.objects.create(
				bk_catgry = cat_obj ,
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				author = request.POST.get('author'),
				price = request.POST.get('price'),
				publisher = request.POST.get('publisher'),
				pub_date= request.POST.get('pub_date'),
				cover_img = request.FILES.get('cover_img'),
				pub_agrmnt = request.FILES.get('pub_agrmnt')
				)
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListBookView(View):
	template_name = 'book_list.html'
	def get(self,request):
		bk_list = BooksModel.objects.all()
		context = {
		'book' :bk_list
		}
		return render(request,self.template_name,context)




		

