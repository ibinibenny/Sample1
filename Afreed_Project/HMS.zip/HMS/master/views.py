from django.shortcuts import render,redirect

# Create your views here.
from django.views.generic import View
from master.models import DepartmentModel
from master.forms import DepartmentForm


class CreateDepartmentView(View):
	template_name = 'department.html'
	form_class = DepartmentForm

	def get(self,request):
		form = self.form_class()
		context = {
		'dptmt_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			dpt = DepartmentModel.objects.create(
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				hod = request.POST.get('hod'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				)	
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListDepartmentView(View):
	template_name = 'list_department.html'

	def get(self,request):
		lst_dptmt = DepartmentModel.objects.all()
		context = {
		'deptmnt' :lst_dptmt
		}
		return render(request,self.template_name,context)

class DepartmentDeailView(View):	
	template_name = 'department_detail.html'

	def get(self,request,pk):
		obj = DepartmentModel.objects.get(id=pk)
		context = {
		'deptmnt' :obj
		}
		return render(request,self.template_name,context)


class DeleteDepartmentView(View):
	template_name = 'list_department.html'

	def get(self,request,pk):
		dptmt_form = DepartmentModel.objects.get(id=pk).delete()
		lst_dptmt = DepartmentModel.objects.all()
		context = {
		'deptmnt' :lst_dptmt
		}
		return render(request,self.template_name,context)						