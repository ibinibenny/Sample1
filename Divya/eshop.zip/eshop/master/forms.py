from django import forms

from master.models import FeedbackModel
from master.models import CategoryModel

class FeedbackForm(forms.ModelForm):
	class Meta:
		model = FeedbackModel
		fields = ['name','email','contact','message','place']

class CategoryForm(forms.ModelForm):
	class Meta:
		model = CategoryModel
		fields = ['title','description']
