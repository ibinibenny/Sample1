import json
  
# function to add to JSON
def write_json(data, filename='asl.json'):
    with open(filename,'w') as f:
        json.dump(data, f, indent=4)
      
      
with open('asl.json') as json_file:
    data = json.load(json_file)
      
    temp = data['stu_details']
  
    # python object to be appended
    y = {"student_name":'suhail',
         "student_email": "suhail@geeksforgeeks.org",
         "stu_profile": "Full Time"
        }
  
  
    # appending data to emp_details 
    temp.append(y)
      
write_json(data) 