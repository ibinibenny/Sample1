import json
a = {'lalalala': 3}
myString = json.dumps(a)
print (myString)