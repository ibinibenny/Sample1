function msg(){  
 alert(" succesfully");
 } 
 


