import re
txt="jdsikABVCS325784"
x=re.findall("\D",txt)
print(x)