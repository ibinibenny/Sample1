import re


def text_match(text):
        patterns = '[0-9]{5}$'

        if re.match(patterns,  text):
               print('Found a match!')
        else:
                print('Not matched!')

text_match("345")
text_match("22345667")
 
 