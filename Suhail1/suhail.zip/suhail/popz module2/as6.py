import re
txt = "Djhdfs@#$545s"
b=re.findall("\W",txt)
c=re.findall("\w",txt)
print(b)
print(c)
