
# Raw text 
text = "ajsjiDon@kskskskskks.com 4s44s4s4s4" 
  
#import regex module 
import re 
  
#finding all valid emails using regex 
reg = re.findall(r"[A-Za-z0-9_%+-.]+"
                 r"@[A-Za-z0-9.-]+"
                 r"\.[A-Za-z]{2,5}",text) 
  
#printing all the valid emails found 
print(reg)
