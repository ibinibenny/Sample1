stre=['H','Cl','Na','O']
st=input("enter the molecule :")
print("string is :",st)
x=len(st)
alphabets=0
digits=0
for i in range(x):
	if stre[i].isalpha():
		alphabets=alphabets+1
	if stre[i].isdigit():
		digits=digits+1
print ("letters are: ",alphabets)
print("digits are: ",digits)
