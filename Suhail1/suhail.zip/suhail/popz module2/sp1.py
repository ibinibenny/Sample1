import re
txt="The rain in spain"
x=re.findall("\AThe",txt)
print(x)
if x:
	print("yes match")
else:
	print("no match")	