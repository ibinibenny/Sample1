# mysql> create database organization;
# ERROR 1007 (HY000): Can't create database 'organization'; database exists
# mysql> use organization
# Reading table information for completion of table and column names
# You can turn off this feature to get a quicker startup with -A

# Database changed
# mysql> create table run(id int,first name varchar(15),middile name(15),last name(15),age(5),address(25));
# ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'name varchar(15),middile name(15),last name(15),age(5),address(25))' at line 1
# mysql> create table run(id int,first name varchar(15),middile name varchar(15),last name varchar(15),age(5),address(25));
# ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'name varchar(15),middile name varchar(15),last name varchar(15),age(5),address(2' at line 1
# mysql> create table run(id int,firstname varchar(15),middilename varchar(15),lastname varchar(15),age(5),address(25));
# ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(5),address(25))' at line 1
# mysql> create table run(id int,firstname varchar(15),middilename varchar(15),lastname varchar(15),age int(5),address varchar(25));
# Query OK, 0 rows affected (0.33 sec)

# mysql> insert into run values(119,"suhail","popz","s",24,"ahahhsahsiu");
# Query OK, 1 row affected (0.04 sec)

# mysql> insert into run values(118,"aadil","popz","jaha",24,"ahahhsahsiu");
# Query OK, 1 row affected (0.04 sec)

# mysql> insert into run values(114,"remold","halk","pytthja",20,"ahahhsahsiu");
# Query OK, 1 row affected (0.05 sec)

# mysql> insert into run values(115,"hasil","abdu","ja",20,"ahahhsahsiu");
# Query OK, 1 row affected (0.06 sec)

# mysql> select * from run;
# +------+-----------+-------------+----------+------+-------------+
# | id   | firstname | middilename | lastname | age  | address     |
# +------+-----------+-------------+----------+------+-------------+
# |  119 | suhail    | popz        | s        |   24 | ahahhsahsiu |
# |  118 | aadil     | popz        | jaha     |   24 | ahahhsahsiu |
# |  114 | remold    | halk        | pytthja  |   20 | ahahhsahsiu |
# |  115 | hasil     | abdu        | ja       |   20 | ahahhsahsiu |
# +------+-----------+-------------+----------+------+-------------+
# 4 rows in set (0.00 sec)

# mysql> 
