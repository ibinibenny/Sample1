n=[1,8,9,7,10]
print(tuple(n))