import math as m
print("The value of pi is", m.pi)