file=open("hasil.txt","r")
print(file.readlines(0))
file.close