my_list=[1,2,3,4,5,6,1.5,"hell0"]
print (my_list[4:])

