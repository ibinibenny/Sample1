list1=[2,8,3,4,9]
list1.()
print(list1)