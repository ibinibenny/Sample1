list1=["python","python","programm","hai"]
list1.insert(2,"pytho")
print(list1)
