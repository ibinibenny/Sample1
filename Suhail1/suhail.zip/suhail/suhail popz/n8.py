list1=[1,2,3,4]
list1.reverse()
print(list1)