for char in 'python':
	if char=='y':
		continue
	print("current character",char)	
