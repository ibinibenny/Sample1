a=['a','b','c']
x=enumerate(a)
print(list(x))
