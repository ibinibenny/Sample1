for x in range(1,5):
	print(x)
