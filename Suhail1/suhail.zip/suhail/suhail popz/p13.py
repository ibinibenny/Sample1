for x in xrange(1,5):
	print(x)
