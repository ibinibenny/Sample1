print("suhail">"hyfa")
print("suhail">"fathima")
print("suhail">"noufi")
print("suhail">"safna")