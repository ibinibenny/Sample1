a=int(input("enter the number"))
if a>=0:
	if a==0:
	  print("zero")
	else:
	  print("positive number")
else:
	print("negative number")
 