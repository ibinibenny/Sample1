n=10
sum=0
x=1
while x<=n:
	sum=sum+x
	x=x+1
print("sum",sum)
