a=[1,2,3,4,5]
b=[6,7,8,9,10]
for x in a:
	for y in b:
		print(x,y