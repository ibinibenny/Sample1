i=1
j=5
while j<8:
	print(i,",",j)
	j=j+1
	i=i+i
