num=int(input("enter the number:"))
if num>0:
	print("positive number")
else:
	print("negative number")
