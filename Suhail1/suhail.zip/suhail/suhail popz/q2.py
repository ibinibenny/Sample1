h=5
l=10

h,l=l,h
print("h=",h)
print("l=",l)

