num=int(input("enter the number:"))
if (num%2) == 0:
	print("{0} is even".format(num))
else:
	print("{0} is odd".format(num))

		