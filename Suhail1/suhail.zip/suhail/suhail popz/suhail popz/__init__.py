from simple import a, b
print(a.bar())
print(b.foo())