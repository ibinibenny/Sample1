a=[1,2,3,"hai",7.5]
n=[x for x in range(10) if x<5]
print(n)