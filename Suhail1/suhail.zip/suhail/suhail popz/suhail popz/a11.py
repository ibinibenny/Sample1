dic={"id":254,"name":2445,"age":24}
dic1={k:v for (k,v) in dic.items () if v%2==0}
print(dic1)