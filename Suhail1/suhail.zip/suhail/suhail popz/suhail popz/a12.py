list=[25,41,25,10]
print(min(list))
print(max(list))