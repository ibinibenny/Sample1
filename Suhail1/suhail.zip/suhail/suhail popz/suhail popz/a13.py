num=[54,65,98,74,25,41,1,2,3]
num=[x for x in num if x%2!=0]
print(num)