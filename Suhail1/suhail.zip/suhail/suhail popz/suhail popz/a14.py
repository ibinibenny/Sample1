def printValues():
	l = list()
	for x in range(1,30):
		l.append(x**2)
	print(l[5:])
printValues()		