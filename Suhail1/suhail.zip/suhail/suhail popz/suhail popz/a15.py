num=[1,2,3,4]
print(["list{0}".format (x) for x in num])