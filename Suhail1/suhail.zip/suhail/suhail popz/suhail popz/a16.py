import itertools
num=[4,5,6]
colour=["red","green","yellow"]
value=[256,54,58]
for(a,b,c)in zip(num,colour,value):
	print(a,b,c)