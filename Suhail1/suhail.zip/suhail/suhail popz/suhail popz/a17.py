dic={"name":"suhail","id":254}
dic["age"]=24
print(dic)