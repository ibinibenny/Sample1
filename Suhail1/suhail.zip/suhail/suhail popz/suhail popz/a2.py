str="welcome to our word in python programme"
x=str.upper()
print(x)