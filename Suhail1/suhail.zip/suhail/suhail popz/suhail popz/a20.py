dic={"id":254,"age":24,"code":47}
print(sum(dic.values()))