dic={"english":40,"maths":35,"hindhi":45}
dic["english"]=50
dic["maths"]=60
dic["hindhi"]=70
print(dic)