dic={"id":25,"name":27,"age":24}
for x in range(1,30):
	dic[x]=x**2
print(dic)	