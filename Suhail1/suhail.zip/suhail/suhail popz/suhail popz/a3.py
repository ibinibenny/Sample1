list1=["python",5,7,8,9]
list1.append(2)
list1.count("python")
list1.insert(2,"python")
print(list1)
