dic={1:"hai",2:7,"age":24}
dic1={2:"oio",7:89,"python":"jhh"}
print("/ndictionary with the use of in integar keys:")
print("/ndictionary with the use of in mixed keys:")
print(dic,dic1)