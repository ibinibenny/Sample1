list=[24,54,6,5,70]
print(sum(list))