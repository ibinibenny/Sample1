f=open("hasil.txt","r")
f.seek(10)
print(f.tell())
print(f.readline())
f.close