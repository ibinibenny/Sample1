def muin():
	return("hai")
