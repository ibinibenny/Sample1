import simple_package
print(simple_package.a.add())
print(simple_package.b.subtract())