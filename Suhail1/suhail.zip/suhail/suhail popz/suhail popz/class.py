class Classname:
	I=5
x=Classname()
print(x.I)			

			