class Person:
	def __init__(self,name,age):
		self.name=name
		self.age=age
x=Person("hasil",6)
print(x.name)
print(x.age)
