class Employee:
	def __init__(self,name,salary,age):
			self.name=name
			self.salary=salary
			self.age=age
i=Employee("suhail",48999,24)
print(i.name)
print(i.salary)
print(i.age)			