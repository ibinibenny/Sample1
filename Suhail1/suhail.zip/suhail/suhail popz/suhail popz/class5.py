class Parrot:
	def fly(self):
		print("gsygghhhduh")
	def run(self):
		print("yryturyru")
class Penguine:
	def fly(self):
		print("kilopkuy")
	def run(self):
		print("best monkey in the wolrd:hasil")
def cat(bird):
	bird.run()
c=Parrot()
B=Penguine()
cat(c)
cat(B)
			