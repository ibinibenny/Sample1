import a,b
print(a.add())
print(b.muin())
