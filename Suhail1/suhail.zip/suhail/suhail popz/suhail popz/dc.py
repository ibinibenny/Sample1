my_dict={"id":154,"name":"hello","age":24,"name":"suhail"}
del my_dict
