def default_arg(id,age,name="spectrum"):
	print("id",id)
	print("name",name)
	print("age",age)
	return
default_arg(10,24)

