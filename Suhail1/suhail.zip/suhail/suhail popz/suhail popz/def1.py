def reqiured_arg(str):
	print("python",str)
	return

reqiured_arg("hello")
	