def keyword_arg(name,age,address):
	print("name",name)
	print("age",age)
	print("address",address)
	return

keyword_arg(name="suhail",age=24,address="ggggdhshs")	