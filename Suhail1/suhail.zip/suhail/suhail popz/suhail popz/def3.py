def hai(*hello):
	for arg in hello:
		print(arg)

hai("pyt","program","hdd")				
