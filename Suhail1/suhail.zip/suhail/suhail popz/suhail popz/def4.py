def python(**hai):
	for i in hai.items():
		print(i)
python(n='dhdd',b=5,o="hdhss")