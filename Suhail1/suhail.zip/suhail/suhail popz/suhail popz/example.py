def module(a,b):
	result=a+b
	return result
