def add(a,b):
	return(a+b)
def muin(a,b):
	return(a-b)
def mul(a,b):
	return(a*b)		
