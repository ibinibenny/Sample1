from example3 import*
print(add(5,7))
print(muin(4,3))
print(mul(1,5))
