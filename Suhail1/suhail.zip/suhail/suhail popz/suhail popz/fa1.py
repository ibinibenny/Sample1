num=int(input("enter a number:"))
mod=num%2
if mod>0:
	print("this is an odd number.")
else:
	print("this a even number.")