def find_len(list):
	length=len(list)
list=[2,8,9,7,5,4]
list.sort()
print("second smallest element is:", *list[:2])
