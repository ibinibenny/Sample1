kpm=["red","green","yellow"]
mpl=[15,89,54]
python=dict(zip(kpm,mpl))
print(python)