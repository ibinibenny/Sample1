try:
	f=open("ab.txt","r")
except IOError:
	print("file not found")	
else:
	print("succesfully")	