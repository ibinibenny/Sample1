def python():
	print("hai")
	print("hello")
print(python())	