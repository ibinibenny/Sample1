def add(x,y):
	c=x+y
	return c
result=add(4,5)
print(result)	