def print_data(mylist):
	mylist.append([1,2,3,4])
	print("inside the function:",mylist)
	return 

my_list=[10,20,30]	
print_data(my_list)
print("outside the function",my_list)