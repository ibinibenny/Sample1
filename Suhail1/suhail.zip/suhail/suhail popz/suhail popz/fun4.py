def hello(name,message):
	print("hello",name+","+message)

hello("hai","hello world")
print()	