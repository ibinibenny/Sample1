def python(fun):
	def inner():
		print("hello world")
		fun()
	return inner	
def hasil(hai):
	def inner():
		print("hgdhdh")
		hai()
	return inner		
@python
@hasil
def hello():
	print("programm")	
hello()	
def klm():
	print("kkkkk")
klm()		