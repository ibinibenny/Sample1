file_obj = open("ad.txt","r")

file_obj = open("ad.txt","a")
print(file_obj.write("Hai"))
file_obj.close()