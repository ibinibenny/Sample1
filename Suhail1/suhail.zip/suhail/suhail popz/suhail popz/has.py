file=open("hasil.txt","w")
file.write("helo world in   hasil ")
file.close