class Base:
	def __init__(self,fname,lname):
		self.firstname=fname
		self.lastname=lname
	def fly(self):
		print(self.firstname,self.lastname)
a=Base("suhail","lkl")
a.fly()		