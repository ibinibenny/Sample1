class Aadil:
	def sun(self):
		print("class1")
class Rem(Aadil):
	def sun(self):
		print("class2")
class Eag(Aadil):
	def sun(self):
		print("class3")
class Fly(Rem,Eag):
	def sun(self):
		print("class4")
a=Fly()
a.sun()
Aadil.sun(a)
Rem.sun(a)
Eag.sun(a)



				