class Pyt:
	def hello(x,y):
		return x+y
Pyt.hello=staticmethod(Pyt.hello)
print("sum",Pyt.hello(4,5))		