class Yas:
	def car(self):
		print("class1")
class Sin(Yas):
	def car(self):
		print("class2")
class Apu(Yas):
	def car(self):
		print("class3")
class Ajm(Sin,Apu):
	def car(self):
		print("class4")
c=Ajm()
c.car()
Apu.car(c)
Sin.car(c)
Yas.car(c)									