class Def:
	def __init__(self,text):
		self.message=text
	def fly(self):
		print(self.message)
class Faq(Def):
	def __init__(self,text):
		super().__init__(text)
v=Faq("aadilhgjj")
v.fly()
					