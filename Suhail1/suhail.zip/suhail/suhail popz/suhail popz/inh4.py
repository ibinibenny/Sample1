class Class1:
	def run(self):
		print("ggisai")
class Class2(Class1):
	def run(self):
		print("kkkk")
class Class3(Class2):
	def run(self):
		print("hhhh")
a=Class3()
a.run()
Class2.run(a)
Class1.run(a)
						