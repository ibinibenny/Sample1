def fly(a,b):
	p=a*b
	return p
def fly(a,b,c):
	p=a*b*c
	return p
e=fly(4,5,4)
r=fly(8,5,6)
o=fly(1,2,8)
print(o)
print(e)	
print(r)