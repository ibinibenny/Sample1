class Human:
	def sayhello(self,name=None):
		if name is not None:
			print("suhail<&>"+name)
		else:
			print("hello")
h=Human()
h.sayhello()
h.sayhello("hyfa")
