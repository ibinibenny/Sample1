class Parent:
	def mymethod(self):
		print("jshhssh")
class Child(Parent):
	def mymethod(self):
		print("kkkk")
a=Child()
a.mymethod()
				