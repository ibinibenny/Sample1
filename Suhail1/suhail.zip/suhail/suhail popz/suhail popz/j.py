f = open("as.txt", "r") 
  
# Second parameter is by default 0 
# sets Reference point to twentieth  
# index position from the beginning 
f.seek(2) 
  
# prints current postion 
 
  
print(f.readline())  
print(f.tell()) 
f.close() 