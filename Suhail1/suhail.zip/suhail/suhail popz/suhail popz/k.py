import json
with open(r"student.json") as f:
	data=json.load(f)
print(data)	