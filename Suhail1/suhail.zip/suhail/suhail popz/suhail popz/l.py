with open("as.txt") as f:
   data = f.read()
print(data)

