l=[]
n=int(input("enter the elements:"))
for i in range(n):
	elements=input()
	l.append(elements)
print(l)	 
