import calendar
yy=2021
mm=2
print(calendar.month(yy,mm))