import mo4 
print(mo4.module(4,5))
