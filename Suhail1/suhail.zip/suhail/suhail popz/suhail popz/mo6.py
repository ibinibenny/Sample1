import math
from math import pi
print(pi)