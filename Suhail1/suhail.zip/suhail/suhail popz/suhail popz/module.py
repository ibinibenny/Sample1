import re

#Check if the string starts with "The" and ends with "Spain":

txt = "The hello world Spain"
x = re.search("^The.*Spain$", txt)

if x:
  print("YES! We have a match!")
else:
  print("No match")