class Vehicle:
    def __init__(self,max_speed, mileage):
        self.max_speed = max_speed
        self.mileage = mileage
a=Vehicle("speed:60","milage:21")
print(a.max_speed)
print(a.mileage)
