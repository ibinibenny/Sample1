d = {320:1, 325:5, 328:3}
print(min(d, key=d.get)) 
