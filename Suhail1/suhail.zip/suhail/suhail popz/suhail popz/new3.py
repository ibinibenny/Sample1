list=[50,60,30,80,10]
list.sort()
print("second largest element is:",list[-2])