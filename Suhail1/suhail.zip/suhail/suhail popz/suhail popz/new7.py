class Employee:
	def __init__ (self,name,salary):
		self.name=name
		self.salary=salary
a=Employee("suhail",9000)
print(a.name)
print(a.salary)	

