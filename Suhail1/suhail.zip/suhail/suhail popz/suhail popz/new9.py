def word_arg(name,age,address):
	print("name",name)
	print("age",age)
	print("address",address)
	return
word_arg(name="suhail",age=24,address="hxyggsg")	