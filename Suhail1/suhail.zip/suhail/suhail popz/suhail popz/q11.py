sum7=0
for i in range(105,200,7):
	sum7=sum7+i
print("the sum of no.s b/w 100&200 div by 7 is:%d\n"%sum7)	