i=int(input("length:"))
w=int(input("width:"))
area=i*w
perimeter=2*(i+w)
print("area of rectangle:",area)
print("perimeter of rectangle:",perimeter)