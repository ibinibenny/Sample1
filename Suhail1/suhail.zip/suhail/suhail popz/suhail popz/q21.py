num_1=10
num_2=11
x=num_1%num_2
print(x)