num_1=7
num_2 = 6
print(num_1 > num_2)
print(num_1 <= num_2)
print(num_1 >= num_2)
