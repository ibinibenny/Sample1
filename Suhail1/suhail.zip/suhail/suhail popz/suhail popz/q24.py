n=6
i=12345
while i<=n:
  i=i+1
print(i)