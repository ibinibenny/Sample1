customer_num =5

invoice_num =1212

print("Invoice No(s):")

while(customer_num >0):

     print("INV -", invoice_num)

     invoice_num = invoice_num +3

     customer_num = customer_num -1