n=int(input("enter the number:"))
for i in range(n,0,-1):
	print((n-i)* ' ' +i * '*') 