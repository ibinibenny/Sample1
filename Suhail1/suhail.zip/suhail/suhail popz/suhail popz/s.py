def fun():
	print("hello")
fun()