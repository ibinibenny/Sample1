num = ['One', 'Two', 'Three']
for i, x in enumerate(num):
    print('{}: {}'.format(i, x),end=" ")

