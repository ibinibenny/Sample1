my_set={(1,2,3),4,"hello",7.5}
print(my_set)