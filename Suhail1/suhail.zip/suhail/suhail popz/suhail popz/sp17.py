dic={"name":"kelly","age":24,"salary":8000,"city":"new york"}
dic[]