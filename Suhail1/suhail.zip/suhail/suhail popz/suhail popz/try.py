a=4
b=45
try:
	print("rsourse open")
	print(a+b)
except Exception as e:
	print("no division",e)	
finally:
	print("rsourse closed")
	