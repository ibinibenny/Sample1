from time import sleep
from threading import * 

class Hello(Thread):
	def run(self):
		for i in range(5):
			print("hello")
			sleep(1)
class Fun(Thread):
	def run(self):
		for i in range(5):
			print("hi")	
			sleep(1)		
x=Hello()
y=Fun()
x.start()
sleep(0.2)
y.start()
x.join()
y.join()



