tup1=(2,6,7,9)
tup2=(1,5,6,8,)
tup3=tup1*4
print(tup3)
