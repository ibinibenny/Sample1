create table customer3(customer_id int,cust_name varchar(20),city varchar(20),grade int,salesman_id int);
Query OK, 0 rows affected (0.34 sec)

mysql> insert into customer3 values(3002,"nick rimando","new york",100,5001);   
Query OK, 1 row affected (0.05 sec)

mysql> insert into customer3 values(3005,"graham zusi","california",200,5002);
Query OK, 1 row affected (0.05 sec)

mysql> insert into customer3 values(3001,"brad guzan","london",,5005);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '5005)' at line 1
mysql> insert into customer3 values(3001,"brad guzan","london"," ",5005);
ERROR 1366 (HY000): Incorrect integer value: ' ' for column 'grade' at row 1
mysql> insert into customer3 values(3001,"brad guzan","london",  ,5005);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '5005)' at line 1
mysql> insert into customer3 values(3001,"brad guzan","london",'',5005);
ERROR 1366 (HY000): Incorrect integer value: '' for column 'grade' at row 1
mysql> insert into customer3 values(3001,"brad guzan","london"," ",5005);
ERROR 1366 (HY000): Incorrect integer value: ' ' for column 'grade' at row 1
mysql> insert into customer3 values(3001,"brad guzan","london",5005);
ERROR 1136 (21S01): Column count doesn't match value count at row 1
mysql> insert into customer3 values(3001,"brad guzan","london",null,5005);
Query OK, 1 row affected (0.05 sec)

mysql> insert into customer3 values(3004,"fabin johns","paris",300,5006);
Query OK, 1 row affected (0.06 sec)

mysql> insert into customer3 values(3007,"brad davis","new york",200,5001);
Query OK, 1 row affected (0.04 sec)

mysql> insert into customer3 values(3009,"geoff camero","berlin",100,5003);
Query OK, 1 row affected (0.06 sec)

mysql> insert into customer3 values(3008,"julian green","london",300,5002);
Query OK, 1 row affected (0.05 sec)

mysql> insert into customer3 values(3003,"jozy altidor","moscow",200,5007);
Query OK, 1 row affected (0.05 sec)

mysql> select * from customer3;
+-------------+--------------+------------+-------+-------------+
| customer_id | cust_name    | city       | grade | salesman_id |
+-------------+--------------+------------+-------+-------------+
|        3002 | nick rimando | new york   |   100 |        5001 |
|        3005 | graham zusi  | california |   200 |        5002 |
|        3001 | brad guzan   | london     |  NULL |        5005 |
|        3004 | fabin johns  | paris      |   300 |        5006 |
|        3007 | brad davis   | new york   |   200 |        5001 |
|        3009 | geoff camero | berlin     |   100 |        5003 |
|        3008 | julian green | london     |   300 |        5002 |
|        3003 | jozy altidor | moscow     |   200 |        5007 |
+-------------+--------------+------------+-------+-------------+
8 rows in set (0.00 sec)

mysql> create table salesman1(salesman_id int, name varchar,city varchar,commission int);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'city varchar,commission int)' at line 1
mysql> create table salesman1(salesman_id int, name varchar(20),city varchar(20),commission int);
Query OK, 0 rows affected (0.37 sec)

mysql> insert into salesman1 values(5001,"james hoog","new york",0.15);
Query OK, 1 row affected (0.04 sec)

mysql> insert into salesman1 values(5002,"nail knite","paris",0.13);
Query OK, 1 row affected (0.04 sec)

mysql> insert into salesman1 values(5005,"pit alex","london",0.11);
Query OK, 1 row affected (0.06 sec)

mysql> insert into salesman1 values(5006,"mc lyon","paris",0.14);
Query OK, 1 row affected (0.05 sec)

mysql> insert into salesman1 values(5003,"lauson hen",null,0.12);
Query OK, 1 row affected (0.05 sec)

mysql> insert into salesman1 values(5007,"paul adam",rome,0.13);
ERROR 1054 (42S22): Unknown column 'rome' in 'field list'
mysql> insert into salesman1 values(5007,"paul adam","rome",0.13);
Query OK, 1 row affected (0.05 sec)

mysql> select * from salesman1;
+-------------+------------+----------+------------+
| salesman_id | name       | city     | commission |
+-------------+------------+----------+------------+
|        5001 | james hoog | new york |          0 |
|        5002 | nail knite | paris    |          0 |
|        5005 | pit alex   | london   |          0 |
|        5006 | mc lyon    | paris    |          0 |
|        5003 | lauson hen | NULL     |          0 |
|        5007 | paul adam  | rome     |          0 |
+-------------+------------+----------+------------+
6 rows in set (0.00 sec)

