mysql> use organization1
Database changed
mysql> select * from customer3;
+-------------+--------------+------------+-------+-------------+
| customer_id | cust_name    | city       | grade | salesman_id |
+-------------+--------------+------------+-------+-------------+
|        3002 | nick rimando | new york   |   100 |        5001 |
|        3005 | graham zusi  | california |   200 |        5002 |
|        3001 | brad guzan   | london     |  NULL |        5005 |
|        3004 | fabin johns  | paris      |   300 |        5006 |
|        3007 | brad davis   | new york   |   200 |        5001 |
|        3009 | geoff camero | berlin     |   100 |        5003 |
|        3008 | julian green | london     |   300 |        5002 |
|        3003 | jozy altidor | moscow     |   200 |        5007 |
+-------------+--------------+------------+-------+-------------+
8 rows in set (0.00 sec)

mysql> select * from salesman1;
+-------------+------------+----------+------------+
| salesman_id | name       | city     | commission |
+-------------+------------+----------+------------+
|        5001 | james hoog | new york |          0 |
|        5002 | nail knite | paris    |          0 |
|        5005 | pit alex   | london   |          0 |
|        5006 | mc lyon    | paris    |          0 |
|        5003 | lauson hen | NULL     |          0 |
|        5007 | paul adam  | rome     |          0 |
+-------------+------------+----------+------------+
6 rows in set (0.00 sec)

mysql> create table orders(ord_no int,purch_amt int,ord_date datetime,customer_id int,salesman_id int);
Query OK, 0 rows affected (0.33 sec)

mysql> insert into orders values(70001,150.5,"2021-10-05",3005,5002);
Query OK, 1 row affected (0.08 sec)

mysql> insert into orders values(70009,270.65,"2012-09-10",3001,5005);
Query OK, 1 row affected (0.06 sec)

mysql> insert into orders values(70002,65.26,"2012-10-05",3002,5001);
Query OK, 1 row affected (0.09 sec)

mysql> insert into orders values(70004,110.05,"2012-08-17",3009,5003);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70007,948.5,"2012-09-10",3005,5002);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70005,2400.6,"2012-07-27",3007,5001);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70008,5760,"2012-09-10",3002,5001);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70010,1983.43,"2012-10-10",3004,5006);
Query OK, 1 row affected (0.04 sec)

mysql> insert into orders values(70003,2480.4,"2012-10-10",3009,5003);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70012,250.45,"2012-06-27",3008,5002);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70011,75.29,"2012-08-17",3003,5007);
Query OK, 1 row affected (0.05 sec)

mysql> insert into orders values(70013,3045.6,"2012-04-25",3002,5001);
Query OK, 1 row affected (0.06 sec)

mysql> select * from orders;
+--------+-----------+---------------------+-------------+-------------+
| ord_no | purch_amt | ord_date            | customer_id | salesman_id |
+--------+-----------+---------------------+-------------+-------------+
|  70001 |       151 | 2021-10-05 00:00:00 |        3005 |        5002 |
|  70009 |       271 | 2012-09-10 00:00:00 |        3001 |        5005 |
|  70002 |        65 | 2012-10-05 00:00:00 |        3002 |        5001 |
|  70004 |       110 | 2012-08-17 00:00:00 |        3009 |        5003 |
|  70007 |       949 | 2012-09-10 00:00:00 |        3005 |        5002 |
|  70005 |      2401 | 2012-07-27 00:00:00 |        3007 |        5001 |
|  70008 |      5760 | 2012-09-10 00:00:00 |        3002 |        5001 |
|  70010 |      1983 | 2012-10-10 00:00:00 |        3004 |        5006 |
|  70003 |      2480 | 2012-10-10 00:00:00 |        3009 |        5003 |
|  70012 |       250 | 2012-06-27 00:00:00 |        3008 |        5002 |
|  70011 |        75 | 2012-08-17 00:00:00 |        3003 |        5007 |
|  70013 |      3046 | 2012-04-25 00:00:00 |        3002 |        5001 |
+--------+-----------+---------------------+-------------+-------------+
12 rows in set (0.00 sec)

mysql> udate orders SET ord_date="2012-10-05" where salesman_id=5002;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'udate orders SET ord_date="2012-10-05" where salesman_id=5002' at line 1
mysql> udate orders SET ord_date=2012-10-05 where salesman_id=5002;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'udate orders SET ord_date=2012-10-05 where salesman_id=5002' at line 1
mysql> update orders SET ord_date=2012-10-05 where salesman_id=5002;
ERROR 1292 (22007): Incorrect datetime value: '1997' for column 'ord_date' at row 1
mysql> update orders SET ord_date="2012-10-05" where salesman_id=5002;
Query OK, 3 rows affected (0.05 sec)
Rows matched: 3  Changed: 3  Warnings: 0

mysql> select * from orders;
+--------+-----------+---------------------+-------------+-------------+
| ord_no | purch_amt | ord_date            | customer_id | salesman_id |
+--------+-----------+---------------------+-------------+-------------+
|  70001 |       151 | 2012-10-05 00:00:00 |        3005 |        5002 |
|  70009 |       271 | 2012-09-10 00:00:00 |        3001 |        5005 |
|  70002 |        65 | 2012-10-05 00:00:00 |        3002 |        5001 |
|  70004 |       110 | 2012-08-17 00:00:00 |        3009 |        5003 |
|  70007 |       949 | 2012-10-05 00:00:00 |        3005 |        5002 |
|  70005 |      2401 | 2012-07-27 00:00:00 |        3007 |        5001 |
|  70008 |      5760 | 2012-09-10 00:00:00 |        3002 |        5001 |
|  70010 |      1983 | 2012-10-10 00:00:00 |        3004 |        5006 |
|  70003 |      2480 | 2012-10-10 00:00:00 |        3009 |        5003 |
|  70012 |       250 | 2012-10-05 00:00:00 |        3008 |        5002 |
|  70011 |        75 | 2012-08-17 00:00:00 |        3003 |        5007 |
|  70013 |      3046 | 2012-04-25 00:00:00 |        3002 |        5001 |
+--------+-----------+---------------------+-------------+-------------+
12 rows in set (0.00 sec)

mysql> 
