select customer3.cust_name, salesman1.name from customer3,salesman1 where salesman1.salesman_id = customer3.salesman_id;
+--------------+------------+
| cust_name    | name       |
+--------------+------------+
| nick rimando | james hoog |
| graham zusi  | nail knite |
| brad guzan   | pit alex   |
| fabin johns  | mc lyon    |
| brad davis   | james hoog |
| geoff camero | lauson hen |
| julian green | nail knite |
| jozy altidor | paul adam  |
+--------------+------------+
