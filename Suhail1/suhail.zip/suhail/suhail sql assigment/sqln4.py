select customer3.cust_name,salesman1.name,salesman1.city from salesman1,customer3 where salesman1.city = customer3.city;
+--------------+------------+----------+
| cust_name    | name       | city     |
+--------------+------------+----------+
| nick rimando | james hoog | new york |
| brad guzan   | pit alex   | london   |
| fabin johns  | nail knite | paris    |
| fabin johns  | mc lyon    | paris    |
| brad davis   | james hoog | new york |
| julian green | pit alex   | london   |
+--------------+------------+----------+
