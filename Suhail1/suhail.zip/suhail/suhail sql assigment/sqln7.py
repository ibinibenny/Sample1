SELECT customer3.cust_name AS "Customer",
customer3.grade AS "Grade"
FROM orders, salesman1, customer3
WHERE orders.customer_id = customer3.customer_id
AND orders.salesman_id = salesman1.salesman_id
AND salesman1.city IS NOT NULL
AND customer3.grade IS NOT NULL;s
+--------------+-------+
| Customer3    | Grade |
+--------------+-------+
| nick rimando |   100 |
| nick rimando |   100 |
| nick rimando |   100 |
| graham zusi  |   200 |
| graham zusi  |   200 |
| fabin johns  |   300 |
| brad davis   |   200 |
| julian green |   300 |
| jozy altidor |   200 |
+--------------+-------+
9 rows in set (0.01 sec)

