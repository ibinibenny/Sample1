select concat(first_name," ",last_name)as complete_name from worker5;
+-----------------+
| complete_name   |
+-----------------+
| monika arora    |
| niharika verma  |
| vishal singhal  |
| amitabh singh   |
| vivek bhati     |
| vipul diwan     |
| satish kumar    |
| geetika chauhan |
+-----------------+
8 rows in set (0.00 sec)
