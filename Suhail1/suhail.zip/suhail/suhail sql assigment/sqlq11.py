select first_name from worker5 order by first_name desc
    -> ;
+------------+
| first_name |
+------------+
| vivek      |
| vishal     |
| vipul      |
| satish     |
| niharika   |
| monika     |
| geetika    |
| amitabh    |
+------------+
