 select * from worker5 where first_name not in("satish","monika");
+-----------+------------+-----------+--------+---------------------+------------+
| worker_id | first_name | last_name | salary | JOINING_DATE        | department |
+-----------+------------+-----------+--------+---------------------+------------+
|         2 | niharika   | verma     |  80000 | 2014-06-11 09:00:00 | admin      |
|         3 | vishal     | singhal   | 300000 | 2014-02-20 09:00:00 | HR         |
|         4 | amitabh    | singh     | 500000 | 2014-02-20 09:00:00 | admin      |
|         5 | vivek      | bhati     | 500000 | 2014-06-11 09:00:00 | admin      |
|         6 | vipul      | diwan     | 200000 | 2014-06-11 09:00:00 | account    |
|         8 | geetika    | chauhan   |  90000 | 2014-04-11 09:00:00 | admin      |
+-----------+------------+-----------+--------+---------------------+------------+
