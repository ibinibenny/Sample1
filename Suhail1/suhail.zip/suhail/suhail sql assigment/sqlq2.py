create table worker4(worker_id int primary key,first_name varchar(25),last_name varchar(25),salary int,JOINING_DATE datetime,department varchar(25));
Query OK, 0 rows affected (0.34 sec)

mysql> create table bonus(
    -> ;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
mysql> create table bonus1(bonus_date datetime,bouns_amount int,worker_ref_id int,foreign key(worker_ref_id) references worker4(worker_id));
Query OK, 0 rows affected (0.67 sec)

mysql> insert into worker4 values(001,"monika","arora",100000,"2014-02-20 09:00:00","HR");
Query OK, 1 row affected (0.05 sec)

mysql> insert into worker4 values(002,"niharika","verma",80000,"2014-06-11 09:00:00","admin");
Query OK, 1 row affected (0.05 sec)

mysql> insert into worker5 values(003,"vishal","singhal",300000,"2014-02-20 09:00:00","HR");
Query OK, 1 row affected (0.04 sec)

mysql> insert into worker5 values(004,"amitabh","singh",500000,"2014-02-20 09:00:00","admin");
Query OK, 1 row affected (0.05 sec)

mysql> insert into worker5 values(005,"vivek","bhati",500000,"2014-06-11 09:00:00","admin");
Query OK, 1 row affected (0.05 sec)

mysql> insert into worker5 values(006,"vipul","diwan",200000,"2014-06-11 09:00:00","account");
Query OK, 1 row affected (0.28 sec)

mysql> insert into worker4 values(007,"satish","kumar",75000,"2014-01-20 09:00:00","account");
Query OK, 1 row affected (0.05 sec)

mysql> insert into worker5 values(008,"geetika","chauhan",90000,"2014-04-11 09:00:00","admin");
Query OK, 1 row affected (0.07 sec)

mysql> select * from worker4;
+-----------+------------+-----------+--------+---------------------+------------+
| worker_id | first_name | last_name | salary | JOINING_DATE        | department |
+-----------+------------+-----------+--------+---------------------+------------+
|         1 | monika     | arora     | 100000 | 2014-02-20 09:00:00 | HR         |
|         2 | niharika   | verma     |  80000 | 2014-06-11 09:00:00 | admin      |
|         3 | vishal     | singhal   | 300000 | 2014-02-20 09:00:00 | HR         |
|         4 | amitabh    | singh     | 500000 | 2014-02-20 09:00:00 | admin      |
|         5 | vivek      | bhati     | 500000 | 2014-06-11 09:00:00 | admin      |
|         6 | vipul      | diwan     | 200000 | 2014-06-11 09:00:00 | account    |
|         7 | satish     | kumar     |  75000 | 2014-01-20 09:00:00 | account    |
|         8 | geetika    | chauhan   |  90000 | 2014-04-11 09:00:00 | admin      |
+-----------+------------+-----------+--------+---------------------+------------+
8 rows in set (0.00 sec)

mysql> insert into bointo bonus values("2016-02-20 00:00:00",500,1);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bonus values("2016-02-20 00:00:00",500,1)' at line 1
mysql> insert into into bonus values("2016-02-20 00:00:00",500,001);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'into bonus values("2016-02-20 00:00:00",500,001)' at line 1
mysql> insert into  bonus1 values("2016-02-20 00:00:00",500,001);
Query OK, 1 row affected (0.05 sec)

mysql> insert into  bonus3 values("2016-06-11 00:00:00",3000,2);
Query OK, 1 row affected (0.11 sec)

mysql> insert into  bonus3 values("2016-02-20 00:00:00",4000,3);
Query OK, 1 row affected (0.04 sec)

mysql> insert into  bonus3 values("2016-02-20 00:00:00",4500,4);
Query OK, 1 row affected (0.05 sec)

mysql> insert into  bonus values("2016-06-11 00:00:00",3500,2);
Query OK, 1 row affected (0.06 sec)

mysql> select * from bonus;
+---------------------+--------------+---------------+
| bonus_date          | bouns_amount | worker_ref_id |
+---------------------+--------------+---------------+
| 2016-02-20 00:00:00 |          500 |             1 |
| 2016-06-11 00:00:00 |         3000 |             2 |
| 2016-02-20 00:00:00 |         4000 |             3 |
| 2016-02-20 00:00:00 |         4500 |             4 |
| 2016-06-11 00:00:00 |         3500 |             2 |
+---------------------+--------------+---------------+
5 rows in set (0.00 sec)

mysql> 
