create database organization1;
use organization1
create table worker5(worker_id int primary key,first_name varchar(25),last_name varchar(25),salary int,JOINING_DATE datetime,department varchar(25));
  insert into worker5 values(002,"niharika","verma",80000,"2014-06-11 09:00:
insert into worker5 values(003,"vishal","singhal",300000,"2014-02-20 09:00:00","HR");
 insert into worker5 values(004,"amitabh","singh",500000,"2014-02-20 09:00:00","admin");
mysql> select * from worker5;
+-----------+------------+-----------+--------+---------------------+------------+
| worker_id | first_name | last_name | salary | JOINING_DATE        | department |
+-----------+------------+-----------+--------+---------------------+------------+
|         1 | monika     | arora     | 100000 | 2014-02-20 09:00:00 | HR         |
|         2 | niharika   | verma     |  80000 | 2014-06-11 09:00:00 | admin      |
|         3 | vishal     | singhal   | 300000 | 2014-02-20 09:00:00 | HR         |
|         4 | amitabh    | singh     | 500000 | 2014-02-20 09:00:00 | admin      |
|         5 | vivek      | bhati     | 500000 | 2014-06-11 09:00:00 | admin      |
|         6 | vipul      | diwan     | 200000 | 2014-06-11 09:00:00 | account    |
|         7 | satish     | kumar     |  75000 | 2014-01-20 09:00:00 | account    |
|         8 | geetika    | chauhan   |  90000 | 2014-04-11 09:00:00 | admin      |
