select first_name "worker name" from worker5;
+-------------+
| worker name |
+-------------+
| monika      |
| niharika    |
| vishal      |
| amitabh     |
| vivek       |
| vipul       |
| satish      |
| geetika     |
+-------------+
