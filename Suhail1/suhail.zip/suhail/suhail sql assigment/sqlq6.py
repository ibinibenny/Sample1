mysql> select distinct worker_id from worker5;
+-----------+
| worker_id |
+-----------+
|         1 |
|         2 |
|         3 |
|         4 |
|         5 |
|         6 |
|         7 |
|         8 |
+-----------+
8 rows in set (0.01 sec)
