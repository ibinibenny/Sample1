 SELECT SUBSTRING(first_name,1,3) 
     FROM worker5;
+---------------------------+
| SUBSTRING(first_name,1,3) |
+---------------------------+
| mon                       |
| nih                       |
| vis                       |
| ami                       |
| viv                       |
| vip                       |
| sat                       |
| gee                       |
+---------------------------+
8 rows in set (0.00 sec)
