mysql> select TRIM(first_name) from worker5;
+------------------+
| TRIM(first_name) |
+------------------+
| monika           |
| niharika         |
| vishal           |
| amitabh          |
| vivek            |
| vipul            |
| satish           |
| geetika          |
+------------------+
8 rows in set (0.00 sec)
