select replace (first_name,"a","A") as "replace name" from worker5;
+--------------+
| replace name |
+--------------+
| monikA       |
| nihArikA     |
| vishAl       |
| AmitAbh      |
| vivek        |
| vipul        |
| sAtish       |
| geetikA      |
+--------------+
8 rows in set (0.00 sec