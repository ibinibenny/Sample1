function required(inputtx) 
   {
     if (inputtx.value.length == 0)
      { 
         alert("message");      
         return false; 
      }      
      return true; 
    }
