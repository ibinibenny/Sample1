import json
x= { "name":"Amal", "age":22, "place":"Ernakulam", "phone":8897456286}
a= { "name":"Afreed", "age":23, "place":"Ernakulam", "phone":6297456286}
b= { "name":"Divya", "age":55, "place":"kochi", "phone":7797456286}
c= { "name":"Sachin", "age":23, "place":"Aroor", "phone":8891456286}
z=json.dumps(c)
print(z)
d=json.dumps(x)
print(d)
