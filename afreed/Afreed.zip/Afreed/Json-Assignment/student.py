import json
  
  

def write_json(data, filename='student.json'):
    with open(filename,'w') as f:
        json.dump(data, f, indent=4)
      
      
with open('student.json') as json_file:
    data = json.load(json_file)
      
    temp = data['std_details']
  

    y = {"std_name":"karthik",
			"age":25,
			"email":"karthik@gmail.com",
			"address":"affdfghj"
		}
   
  
  

    temp.append(y)
      
write_json(data)