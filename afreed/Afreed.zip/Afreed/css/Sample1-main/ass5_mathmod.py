import math
num1=int(input("enter no. :"))
print("square and cube of %d is %d" %(pow(num1,2),pow(num1,3)))
power=int(input("power:"))
print("%d ^ %d is %d " %(num1,power,pow(num1,power)))
print("sq root of %d is %d" %(num1,math.sqrt(num1)))
print("log and exp value of %d is %d & %d" %(num1,math.log(num1),math.exp(num1)))

