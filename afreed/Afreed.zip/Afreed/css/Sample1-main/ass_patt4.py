k=65
for i in range(65,70):
	for j in range(66,i+1):
		print(chr(k),end=' ')
		k+=1
	print("\n")
	
	
		
