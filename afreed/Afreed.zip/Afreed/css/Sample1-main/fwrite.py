#1. Write a program to create a new file and write data to it 

