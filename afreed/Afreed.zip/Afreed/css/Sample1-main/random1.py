import random

mylist = ["apple", "banana", "cherry"]

print(random.choice(mylist))