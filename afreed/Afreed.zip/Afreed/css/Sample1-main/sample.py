import hello

hello.New()
c=hello.New().a
print(c)
