try:
	num1=int(input("num1?"))
	num2=int(input("num2?"))
	print(num1/num2)
except:
	print("0 division error")

