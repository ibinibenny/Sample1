try:
    raise TypeError("type mismatch!!")
#except TypeError as e:
 #   print(e)
