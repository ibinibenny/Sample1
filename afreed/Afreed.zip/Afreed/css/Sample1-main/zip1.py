import zipfile
zip=zipfile.ZipFile("tstworks.zip")
zip.extractall()
