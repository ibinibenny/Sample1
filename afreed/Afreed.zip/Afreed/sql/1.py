python@python-H110M-S2:~$ su -
Password: 
root@python-H110M-S2:~# mysql -u root -p
Enter password: 
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 4
Server version: 5.7.33-0ubuntu0.18.04.1 (Ubuntu)

Copyright (c) 2000, 2021, Oracle and/or its affiliates.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> create database organization10;
Query OK, 1 row affected (0.00 sec)

mysql> CREATE TABLE Worker (
    -> WORKER_ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    -> FIRST_NAME CHAR(25),
    -> LAST_NAME CHAR(25),
    -> SALARY INT(15),
    -> JOINING_DATE DATETIME,
    -> DEPARTMENT CHAR(25)
    -> );
mysql> use organization10;
Database changed
mysql> CREATE TABLE Worker ( WORKER_ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT, FIRST_NAME CHAR(25), LAST_NAME CHAR(25), SALARY INT(15), JOINING_DATE DATETIME, DEPARTMENT CHAR(25) );
Query OK, 0 rows affected (0.39 sec)

mysql> insert into Worker values(001,'Monika','Arora',100000,'2014-02-20 09:00:00'
Query OK, 1 row affected (0.05 sec)

mysql> insert into Worker values(002,'Niharika','Verma',80000,'2014-06-11 09:00:00','Admin');
Query OK, 1 row affected (0.06 sec)

mysql> insert into Worker values(003,'Vishal','Singhal',300000,'2014-02-20 09:00:00','HR');
Query OK, 1 row affected (0.05 sec)

mysql> insert into Worker values(004,'Amitabh','Singh',500000,'2014-02-20 09:00:00','Admin');
Query OK, 1 row affected (0.06 sec)

mysql> insert into Worker values(005,'Vivek','Bhati',500000,'2014-06-11 09:00:00','Admin');
Query OK, 1 row affected (0.20 sec)

mysql> insert into Worker values(006,'Vipul','Diwan',200000,'2014-06-11 09:00:00','Account');
Query OK, 1 row affected (0.04 sec)

mysql> insert into Worker values(007,'Satish','Kumar',75000,'2014-01-20 09:00:00','Account');
Query OK, 1 row affected (0.07 sec)

mysql> insert into Worker values(008,'Geetika','Chauhan',90000,'2014-04-11 09:00:00','Admin');
Query OK, 1 row affected (0.05 sec)

mysql> select * from Worker;
+-----------+------------+-----------+--------+---------------------+------------+
| WORKER_ID | FIRST_NAME | LAST_NAME | SALARY | JOINING_DATE        | DEPARTMENT |
+-----------+------------+-----------+--------+---------------------+------------+
|         1 | Monika     | Arora     | 100000 | 2014-02-20 09:00:00 | HR         |
|         2 | Niharika   | Verma     |  80000 | 2014-06-11 09:00:00 | Admin      |
|         3 | Vishal     | Singhal   | 300000 | 2014-02-20 09:00:00 | HR         |
|         4 | Amitabh    | Singh     | 500000 | 2014-02-20 09:00:00 | Admin      |
|         5 | Vivek      | Bhati     | 500000 | 2014-06-11 09:00:00 | Admin      |
|         6 | Vipul      | Diwan     | 200000 | 2014-06-11 09:00:00 | Account    |
|         7 | Satish     | Kumar     |  75000 | 2014-01-20 09:00:00 | Account    |
|         8 | Geetika    | Chauhan   |  90000 | 2014-04-11 09:00:00 | Admin      |
+-----------+------------+-----------+--------+---------------------+------------+
8 rows in set (0.00 sec)

mysql> CREATE TABLE Bonus4(
    -> WORKER_REF_ID INT,
    -> BONUS_DATE DATETIME,
    -> BONUS_AMOUNT INT(10),
    -> FOREIGN KEY (WORKER_REF_ID)
    -> 
Display all 802 possibilities? (y or n) 
    -> REFERENCES Worker(WORKER_ID)
    -> ON DELETE CASCADE
    -> );
Query OK, 0 rows affected (0.51 sec)

mysql> insert into Bonus4 values(1,'2016-02-20 00:00:00',5000);
Query OK, 1 row affected (0.03 sec)

mysql> insert into Bonus4 values(2,'2016-06-11 00:00:00',3000);
Query OK, 1 row affected (0.05 sec)

mysql> insert into Bonus4 values(3,'2016-02-20 00:00:00',4000);
Query OK, 1 row affected (0.06 sec)

mysql> insert into Bonus4 values(1,'2016-02-20 00:00:00',4500);
Query OK, 1 row affected (0.05 sec)

mysql> insert into Bonus4 values(2,'2016-06-11 00:00:00',3500);
Query OK, 1 row affected (0.04 sec)

mysql> select * from Bonus4;
+---------------+---------------------+--------------+
| WORKER_REF_ID | BONUS_DATE          | BONUS_AMOUNT |
+---------------+---------------------+--------------+
|             1 | 2016-02-20 00:00:00 |         5000 |
|             2 | 2016-06-11 00:00:00 |         3000 |
|             3 | 2016-02-20 00:00:00 |         4000 |
|             1 | 2016-02-20 00:00:00 |         4500 |
|             2 | 2016-06-11 00:00:00 |         3500 |
+---------------+---------------------+--------------+
5 rows in set (0.00 sec)

mysql> 
