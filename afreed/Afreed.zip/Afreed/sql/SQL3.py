mysql> select FIRST_NAME as Worker_name from Worker;
+-------------+
| Worker_name |
+-------------+
| Monika      |
| Niharika    |
| Vishal      |
| Amitabh     |
| Vivek       |
| Vipul       |
| Satish      |
| Geetika     |
+-------------+
8 rows in set (0.00 sec)
