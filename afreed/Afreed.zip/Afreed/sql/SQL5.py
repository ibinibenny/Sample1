mysql> select upper(FIRST_NAME) from Worker;
+-------------------+
| upper(FIRST_NAME) |
+-------------------+
| MONIKA            |
| NIHARIKA          |
| VISHAL            |
| AMITABH           |
| VIVEK             |
| VIPUL             |
| SATISH            |
| GEETIKA           |
+-------------------+
8 rows in set (0.00 sec)

