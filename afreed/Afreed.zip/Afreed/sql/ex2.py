import sqlite3
conn = sqlite3.connect('javatpoint.db')
print ("opened database successfully")
conn.execute(''')