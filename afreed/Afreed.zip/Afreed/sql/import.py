import sqlite3  
  
conn = sqlite3.connect('javatpoint.db')  
  
print ("Opened database successfully") 