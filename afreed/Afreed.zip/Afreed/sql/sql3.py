import sqlite3  
  
conn = sqlite3.connect('javatpoint.db')  
  
data = conn.execute("select * from Employee");  
  
for row in data:  
   print("ID = ", row[0])  
   print("NAME = ", row[1]) 
   print("AGE = ", row[2]) 
   print("ADDRESS = ", row[3])  
   print("SALARY = ", row[4]) 
  
conn.close();  