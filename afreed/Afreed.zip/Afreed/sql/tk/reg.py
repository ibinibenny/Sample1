from tkinter import *
from functools import partial

def validateLogin(fname,lname,username,password):
	print("Firstname entered :",fname.get())
	print("Lastname entered :", lname.get())
	print("Username entered :", username.get())
	print("Password entered :", password.get())
	return

tkWindow = Tk()  
tkWindow.geometry('800x900')  
tkWindow.title('Registration Form - pythonexamples.org')   

fnameLabel = Label(tkWindow, text="Firstname").grid(row=0, column=0)
fname = StringVar()
fnameEntry = Entry(tkWindow, textvariable=fname).grid(row=0, column=1)

lnameLabel = Label(tkWindow, text="Lastname").grid(row=1, column=0)
lname = StringVar()
fnameEntry = Entry(tkWindow, textvariable=lname).grid(row=1, column=1)

usernameLabel = Label(tkWindow, text="User Name").grid(row=2, column=0)
username = StringVar()
usernameEntry = Entry(tkWindow, textvariable=username).grid(row=2, column=1) 


passwordLabel = Label(tkWindow,text="Password").grid(row=3, column=0)  
password = StringVar()
passwordEntry = Entry(tkWindow, textvariable=password, show='*').grid(row=3, column=1)

validateLogin = partial(validateLogin,fname,lname,username,password)

loginButton = Button(tkWindow, text="Register", command=validateLogin).grid(row=4, column=0)

tkWindow.mainloop()