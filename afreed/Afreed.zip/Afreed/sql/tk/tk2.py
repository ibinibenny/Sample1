from tkinter import *   
  
  
top = Tk()  
  
top.geometry("700x800")  
  
b = Button(top,text = "Submit")  
  
b.pack()  
  
top.mainloop()  
