
#Python offers multiple options for developing GUI (Graphical User Interface). 

#Python provides the standard library Tkinter for creating the graphical user interface for desktop based applications

#Python with tkinter is the fastest and easiest way to create the GUI applications. Creating a GUI using tkinter is an easy task.

#To create a tkinter app:

    #Importing the module – tkinter
    #Create the main window (container)
    #Add any number of widgets to the main window
    #Apply the event Trigger on the widgets.
    
    

import tkinter
from tkinter import *  
    #creating the application main window.   
top = Tk()  
    #Entering the event main loop  
top.mainloop()
