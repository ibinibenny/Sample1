# -*- coding: utf-8 -*-
from django.contrib import admin

from master.models import FeedbackModel,CategoryModel,BookCategoryModel
# Register your models here.


admin.site.register(FeedbackModel)

admin.site.register(CategoryModel)

admin.site.register(BookCategoryModel)