# -*- coding: utf-8 -*-
from django.shortcuts import render,redirect


from django.views.generic import CreateView,ListView,DetailView,View
#from django.views.generic.base import View
from django.views.generic.edit import UpdateView

from master.models import FeedbackModel
from master.forms import FeedbackForm

from master.models import CategoryModel,BookCategoryModel
from master.forms import CategoryForm,BookCategoryForm


# Create your views here.

class CreateFeedbackView(CreateView):
	template_name= 'create_feedback.html'
	model= FeedbackModel
	form_class= FeedbackForm
	success_url= '/gen/home'


class ListFeedbackView(ListView):
	template_name = 'list_feedback.html'
	model = FeedbackModel
	context_object_name= 'feed'




class CategoryView(CreateView):
	template_name= 'category.html'
	model= CategoryModel
	form_class= CategoryForm
	success_url= '/gen/home'


class CategoryUpdateView(UpdateView):
	template_name= 'update.html'
	model= CategoryModel
	fields = ['title','description']
	#form_class= CategoryForm
	success_url= '/gen/home'





class ListCategoryView(ListView):
	template_name = 'list_category.html'
	model = CategoryModel



class FeedbackDetailView(DetailView):
	template_name = 'feed_details.html'
	model = FeedbackModel


class CategoryDetailView(DetailView):
	template_name = 'category_details.html'
	model = CategoryModel


class BookCategoryView(View):
	template_name = 'book_category.html'
	form_class= BookCategoryForm
	#model = BookCategoryModel

	def get(self,request):
		form = self.form_class()
		mydictionary ={
			'form1' : form
		}
		return render(request,self.template_name,mydictionary)


	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			book_cat = BookCategoryModel.objects.create(
			title = request.POST.get('title'),
			description = request.POST.get('description'),
			cat_code = request.POST.get('cat_code')
			)
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})



class ListBookCategoryView(View):
	template_name = 'list_book_category.html'
	
	def get(self,request):
		book = BookCategoryModel.objects.all()
		mydictionary={
			'cat': book
		}
		return render(request,self.template_name,mydictionary)


class BookCategoryDetailView(View):
	template_name = 'detail_book_category.html'

	def get(self,request,pk):
		obj = BookCategoryModel.objects.get(id=pk)
		mydictionary={
			'cat': obj
		}
		return render(request,self.template_name,mydictionary)		