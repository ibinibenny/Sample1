class New:
	a=5
	def method1(self,c):
		return self.a+c
obj=New()
print(obj.method1(c=5))