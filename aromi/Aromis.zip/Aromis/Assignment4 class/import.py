import hello

hello.New()
b=hello.New().a
print(b)