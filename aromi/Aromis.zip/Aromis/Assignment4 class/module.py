from example import*
print(add(2,6))
print(sub(3,4))
print(div(3,2))
print(mul(2,2))