import os
print(os.name)
print(os.getcwd())