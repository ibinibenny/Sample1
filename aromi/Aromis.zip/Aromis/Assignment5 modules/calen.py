import calendar
yy = 2021 
mm = 3 
print(calendar.month(yy, mm))