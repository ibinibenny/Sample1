from datetime import date 
my_date = date(1996, 12, 11) 
print("Date passed as argument is", my_date) 