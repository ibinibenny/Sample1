from operator3 import *
print(add(3,4))
print(sub(5,2))
print(mul(9,3))
print(truediv(20,6))
print(floordiv(20,6))