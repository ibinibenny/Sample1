def add(a,b):
	result=a+b
	return result
def sub(a,b):
	result=a-b
	return result
def mul(a,b):
	result=a*b
	return result
def truediv(a,b):
	result=a/b
	return result			
def floordiv//(a,b):	
	result=a//b
	return result 	     	