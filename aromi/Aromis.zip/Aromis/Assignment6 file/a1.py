f=open("file1.txt","w")
print(f.write("hai how r u"))
f.close()
