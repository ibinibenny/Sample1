f=open("a2.txt","r")
print(f.read())
print(f.readline(2))
f.close()