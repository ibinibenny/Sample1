import zipfile
zip=zipfile.ZipFile("Samplemain.zip")
zip.extractall()

