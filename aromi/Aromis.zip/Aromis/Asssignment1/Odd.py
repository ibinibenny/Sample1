num=int(input("Enter a number"))
if (num % 2) == 0:
	print(num,"Number is even")
else:
	print(num,"Number is odd")