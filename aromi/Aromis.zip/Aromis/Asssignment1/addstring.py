def add_string(str1):  
  length = len(str1)  
  if length <5:  
    if str1[-3:]== 'python':  
      str1 += 'hi python'  
    else:  
       str1 += 'php'  
  return str1  
print(add_string(''))  
print(add_string(' '))  
print(add_string(''))  