x=input("Enter a string")
if len(x) < 5:
	print(x,'php')
elif x.endswith('python'):
	print(x,'java')
else:
	print(x,'python')	
