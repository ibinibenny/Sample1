l=int(input("length:"))
b=int(input("breadth:"))
area=l*b
perimeter=2*(l+b)
print("Area of rectangle:",area)
print("perimeter of rectangle:",perimeter)