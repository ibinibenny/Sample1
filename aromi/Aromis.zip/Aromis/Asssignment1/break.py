for char in "hello":
	if char=="e":
		pass
	print("current character",char)
		