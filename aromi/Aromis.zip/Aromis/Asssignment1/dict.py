n=int(input("enter the elements"))
d={}
for i in range(n):
	keys=input("enter the keys")
	values=input("enter the values")
	d[keys]=values
print(d)	