rows=6
for num in range(rows):
	for i in range(num):
		print(num,end=" ")
	print(" ")