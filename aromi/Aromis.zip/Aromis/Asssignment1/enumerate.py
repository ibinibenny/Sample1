s="hello world"
k=enumerate(s)
print(list(enumerate(s,2)))