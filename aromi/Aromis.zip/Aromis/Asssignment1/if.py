n=int(input("enter the number"))
if n>0:
	print("true")
else:
	print("false") 