l=[]
n=int(input("enter the elements"))
for i in range(0,n):
	e=(input())
	l.append(e)
print(l)	