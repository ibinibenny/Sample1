num=int(input("enter the number:"))
print("multiplication table of",num)
for i in range(1,11):
	print(num,"x",i,"=",num*1)