n=int(input("enter a number"))
if n>=0:
	if n==2:	
		print("two")
	else:
		print("positive numbers")
else:
	print("negative numbers")		
	

