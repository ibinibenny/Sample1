i=1
while i<=6:
	print(i,"outer loop")
	j=1
	while j<=6:
		print(j,"inner")
		j=j+1
	i=i+1