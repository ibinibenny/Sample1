num=input("Enter a number or string:")
if num==num[::-1]:
	print("yes its a palindrome")
else:
	print("yes its not a palindrome")	