for i in range(65,70):
	j=65
	while j<i+1:	
		print(chr(j),end=' ')
		j+=1
	print("\n")
	