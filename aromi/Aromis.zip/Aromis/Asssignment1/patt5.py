k=1
for i in range(1,7):
	for j in range(1,i+1):
		print(k*2,end=' ')
		k+=1
	print("\n")
	