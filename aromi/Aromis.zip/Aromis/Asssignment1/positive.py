num=-33
if num>=0:
	print("num is a positive number")
if num<0:
	print("num is a negative number")	
