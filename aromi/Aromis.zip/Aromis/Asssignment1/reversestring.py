x="hello world"[::-1]
print(x)