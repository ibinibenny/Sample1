>>> x=10
>>> y=11
>>> x%y
10
>>> x*y
110
>>> x-y
-1
>>> 
>>> num_1=7
>>> num_2=6
>>> num_1 < num_2
False
>>> num_1 > num_2
True
>>> num_1 <= num_2
False
>>> num_1 >= num_2
True
>>> num_1==num_2
False
>>> num_1=3
>>> num_2=4
>>> (num_1 < num_2) and (num_1 != num_2)
True
>>> (num_2 >= num_1) or (num_1 > num_2)
True
>>> not (num_1 == num_2)
True
>>> i=1
>>> while (i<6):
...     i = i +1
...     print(i) 
... 
2
3
4
5
6
>>> 
