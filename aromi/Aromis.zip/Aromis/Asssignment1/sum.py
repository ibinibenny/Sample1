num=int(input("Enter a number"))
if(num%2)==1:
	print("num,number is odd")
	