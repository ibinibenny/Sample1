total=0
list1=[11,5,17,18,23] 
for elements in range(0, len(list1)):
    total=total+list1[elements]
print("Sum of all elements in given list:",total)