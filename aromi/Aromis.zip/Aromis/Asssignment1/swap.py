x=4
y=6
x,y=y,x
print("x=",x)
print("y=",y)