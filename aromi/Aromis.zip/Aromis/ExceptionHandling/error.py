try:
	n=int(input("enter the age"))
	if(n<18):
		raise ValueError 
	else:
		print("age is valid")
except ValueError:
	print("age is not valid")
