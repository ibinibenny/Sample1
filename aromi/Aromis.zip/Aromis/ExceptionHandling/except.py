try:
	f=open("file.txt","r")
except IOError:
	print("file not found")
else:
	print("sucessfully")
	f.close()
