try:
	print("open a resource")
	a=int(input("enter the value"))
	b=int(input("enter the value"))
	c=a/b
	print(c)
	print("sucessfull")
	
except Exception as e:
	print("zero division cannot possibile:",e)
	
finally:
	print("closed resource ")                                                         ")	