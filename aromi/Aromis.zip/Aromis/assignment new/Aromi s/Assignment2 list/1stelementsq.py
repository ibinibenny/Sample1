import math
l1=[]
for i in range(1,31):
	l1.append(int(math.pow(i,2)))
print(l1)
for i in range(30):
	if i<5 or i>24:
		print(l1[i])
	