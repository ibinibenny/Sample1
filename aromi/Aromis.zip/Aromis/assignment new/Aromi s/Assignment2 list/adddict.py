x={'name':'abc','age':23}
x['place']="Alappuzha"
print(x)