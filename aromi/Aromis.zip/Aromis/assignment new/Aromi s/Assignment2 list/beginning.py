x=1
y=3
z=l1=[1,2,3,'hlo','pleasure meeting u',68]
print(l1,"\n-------------------------------------------------------------")
for i in range(0,12,2):
	l1.insert(i,'jeswin')
print(l1)	