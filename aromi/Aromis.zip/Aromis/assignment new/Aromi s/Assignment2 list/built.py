List=['Mathematics','chemistry',1997,2000] 
List.append(20544) 
print(List) 