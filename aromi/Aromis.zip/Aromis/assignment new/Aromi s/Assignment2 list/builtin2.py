List1=[1,2,3] 
List2=[2,3,4,5]  
List1.extend(List2)         
print(List1)
List2.extend(List1)  
print(List2) 
