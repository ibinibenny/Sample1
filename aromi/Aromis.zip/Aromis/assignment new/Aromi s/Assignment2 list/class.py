class Myclass:
	x=2
k=Myclass()
print(k.x)