det1={1:10,2:10}
det2={3:10,4:10}
det3={5:10,6:10}
det4={ }
for d in(det1,det2,det3):det4.update(d)
print(det4)