dict1={'name':'ammu','id':678}
dict2={'mark':16,'status':'passed'}
dict1.update(dict2)
print("update dictionary")
print(dict1)