class  Person:
	def __init__(self,name,age):
		self.name=name
		self.age=age
obj=Person("ammu",21)
print(obj.name)
print(obj.age)		

		
		