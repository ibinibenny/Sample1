arr=[1,2,3,4,5,6]  
for i in range(1,len(arr),2):  
    print(arr[i]);   