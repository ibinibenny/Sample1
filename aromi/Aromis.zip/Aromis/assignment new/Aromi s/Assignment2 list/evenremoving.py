l=[]
x=0
n=int(input("enter the list:"))
for i in range(n):
	l.append(int(input("enter the values:")))
print(l)
for x in l:
	if x%2!=0:
		print(x,end=" ")
print()			