def sum(a,b,c):
	z=a+b+c
	return c
x=sum(2,3,4)
print(x)	