a_letters=[]
for letter in 'ammu':
    a_letters.append(letter)
print(a_letters)

