letters=[]
for letter in 'ammu':
    letters.append(letter)
print(letters)

