num=[1,2,3]
color=['red','white','black']
for(a,b)in zip(num,color):
	print(a,b)
	 