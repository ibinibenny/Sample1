d=dict()
for x in range(1,20):
    d[x]=x**2
print(d)  

 