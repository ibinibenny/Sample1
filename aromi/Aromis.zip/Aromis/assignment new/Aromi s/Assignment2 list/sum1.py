l=[]
sum=0
limit=int(input("Enter the limit"))
for i in range(limit):
	l.append(int(input("Enter the values")))
print(l)
for i in l:
	sum=sum+1
print("sum:",sum)	