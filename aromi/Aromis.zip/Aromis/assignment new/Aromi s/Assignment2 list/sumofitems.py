k={'data1':100,'data2':-54,'data3':250}
print(sum(k.values()))