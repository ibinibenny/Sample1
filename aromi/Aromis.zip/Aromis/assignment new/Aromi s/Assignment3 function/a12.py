n=int(input("Enter the ending number:"))
start, end =0,n 
for num in range(start, end + 1): 
    if num % 2 == 0: 
        print(num, end = ",") 
print() 