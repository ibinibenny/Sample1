num=int(input("Enter a number"))
mode=num%2
if mode>0:
	print("This is an odd number")
else:
    print("This is an even number")	