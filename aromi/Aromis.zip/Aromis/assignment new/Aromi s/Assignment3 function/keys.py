k_keys=['wed','kill','Ammu']
k_values=[5,6,7]
print("orginal key list is:", str(k_keys))
print("orginal value list is:" ,str(k_values))
result=dict(zip(k_keys,k_values))
print("resultant dictionary:"+str(result))