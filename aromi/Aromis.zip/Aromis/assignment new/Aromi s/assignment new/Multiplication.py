num1=int(input("enter a number"))
num2=int(input("enter a number"))
product=num1*num2;
print("The multiplication of number is",product)