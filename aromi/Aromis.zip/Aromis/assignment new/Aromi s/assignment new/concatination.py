listA=['monday','day','sun']
listB=['tuesday','day','rise']
print("given list A:",listA)
print("given list B:",listB)
result=[i+j for i, j in zip(listA, listB)]
print("The concatenated lists: ",res)


