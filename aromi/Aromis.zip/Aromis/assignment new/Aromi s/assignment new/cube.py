n=int(input("enter limit"))
for i in range(1,n+1):
	print("number is:",i)
	print("cube of the no: is:",i**3)
	print(i)
	