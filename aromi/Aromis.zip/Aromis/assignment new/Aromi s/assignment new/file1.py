file=open("hai.txt","w")
file.write("hello")
file.close