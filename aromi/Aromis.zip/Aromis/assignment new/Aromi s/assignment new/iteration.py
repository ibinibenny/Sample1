for x in range(155):
	if x%5==0:
		print(x)
		if x>150:
			break
			print(x)