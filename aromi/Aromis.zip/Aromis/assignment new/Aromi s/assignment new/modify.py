tuple1=(11,[22,33],44,55)
tuple1[1][0]=222
print(tuple1)