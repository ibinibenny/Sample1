file_obj = open("file4.txt","a")

for i in range(1,5):
    file_obj.write("Hai")
file_obj.close()