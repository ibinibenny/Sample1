with open("data.txt") as file:
	data = file.read()
	print(data )
	