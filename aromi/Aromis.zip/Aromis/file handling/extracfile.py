import zipfile
zip=zipfile.ZipFile("Sample-main.zip")
zip.extractall()

