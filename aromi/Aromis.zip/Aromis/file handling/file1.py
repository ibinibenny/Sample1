f=open("file1.txt","w")
print(f.write("haiii"))
f.close()