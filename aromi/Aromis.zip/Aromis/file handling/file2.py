f=open("file2.txt","r")
print(f.read())
print(f.readline(5))

f.close()