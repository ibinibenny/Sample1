import json
f=open("output.json","r")
print(json.loads(f.read()))
f.close()

