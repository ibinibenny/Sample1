f_obj = open("file4.txt","r")

for line in f_obj:
    print (line)

f_obj.close()