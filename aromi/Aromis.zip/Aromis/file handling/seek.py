# Opening "GfG.txt" text file 
f = open("file4.txt", "r") 
  
# Second parameter is by default 0 
# sets Reference point to twentieth  
# index position from the beginning 
f.seek(10) 
  
# prints current postion 
print(f.tell()) 
  
print(f.readline())  
f.close() 