import tarfile
tar = tarfile.open("modules.tar.xz","w:xz")
for name in ["ab.py", "Sample-main.zip", "date.py"]:
	tar.add(name)
	print(name)
tar.close()