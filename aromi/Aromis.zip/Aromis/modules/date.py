import datetime
a=datetime.datetime.now()
print(a)