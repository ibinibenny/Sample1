import calendar
calendar.setfirstweekday(6)
print(calendar.firstweekday())
