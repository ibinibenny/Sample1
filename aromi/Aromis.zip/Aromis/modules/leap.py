import calendar
print(calendar.leapdays(2015, 2018))