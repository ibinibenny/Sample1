import random
my_list=["a","k","c"]
print(random.choice(my_list))