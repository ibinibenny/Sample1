import calendar
print(calendar.weekday(2021, 3, 16))

