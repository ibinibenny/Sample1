from django.conf.urls import url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings

from general.views import HomePageView,AboutUsView
from master.views import CreateFeedbackView,ListFeedbackView,CategoryView,FeedbackDetailView,ListCategoryView,CategoryDetailView,NewBookCategoryView,CategoryUpdateView,ListBookCategoryView,BookCategoryView






urlpatterns = [
	url(r'feedback/',CreateFeedbackView.as_view(),name='new_fdbk'),
	url(r'listfeeds/',ListFeedbackView.as_view(),name='list_fdbk'),
	url(r'category/',CategoryView.as_view(),name='category_fdbk'),
	url(r'fdbckdetails/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(),name='fdbk_detail'),
	url(r'listcategry/',ListCategoryView.as_view(),name='list_category'),
	url(r'categorydetails/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='category_detail'),
	url(r'bkcatgry/',NewBookCategoryView.as_view(),name='new_bk_catgry'),
	url(r'<pk>/update',CategoryUpdateView.as_view(),name='new_update'),
	url(r'listbkcatgry/',ListBookCategoryView.as_view(),name='list_bk'),
	url(r'bkcatgory/(?P<pk>[0-9]+)/$',BookCategoryView.as_view(),name='bkcatgry_detail'),
    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



