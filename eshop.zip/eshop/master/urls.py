from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings


from general.views import HomePageView,AboutUsView
from master.views import CreateFeedbackView,ListFeedbackView,CategoryView,FeedbackDetailView,ListCategoryView,CategoryDetailView



urlpatterns = [
	path(r'feedback/',CreateFeedbackView.as_view(),name='new_fdbk'),
	path(r'listfeeds/',ListFeedbackView.as_view(),name='list_fdbk'),
	path(r'category/',CategoryView.as_view(),name='category_fdbk'),
	path(r'fdbckdetails/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(),name='fdbk_detail'),
	path(r'listcategory/',ListCategoryView.as_view(),name='list_category'),
	path(r'categorydetails/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='category_detail')
	
    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	 urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	 urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



