from django.shortcuts import render

from django.views.generic import CreateView,ListView,CreateView,DetailView,ListView,DetailView
from master.models import FeedbackModel
from master.forms  import FeedbackForm
from master.models import CategoryModel
from master.forms import CategoryForm

# Create your views here.

class CreateFeedbackView(CreateView):
	template_name = 'create_feedback.html'
	model = FeedbackModel
	form_class = FeedbackForm
	success_url = '/gen/home/'

class ListFeedbackView(ListView):
	template_name = 'list_feedback.html'
	model = FeedbackModel
	context_object_name = 'feedbacks'

class  CategoryView(CreateView):
	template_name = 'category.html'
	model = CategoryModel
	form_class = CategoryForm
	success_url = '/gen/home/'
		

class FeedbackDetailView(DetailView):
	template_name = 'feedback_details.html'
	model = FeedbackModel

class ListCategoryView(ListView): 
	template_name = 'list_category.html'
	model = CategoryModel
	context_object_name = 'category'

class CategoryDetailView(DetailView):
	template_name = 'category_details.html'
	model = CategoryModel
