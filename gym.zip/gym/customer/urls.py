from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from customer.views import CustomerRegister,Customerlist,UpdateCustomer,DeleteCustomer,LoginView,CustomerHome 
from django.contrib.auth import views as auth_views

urlpatterns = [
   path(r'register/',CustomerRegister.as_view(),name='cust_reg'),
    path(r'customerlist/',Customerlist.as_view(),name='cust_list'),
    path(r'cushome/',CustomerHome.as_view(),name='cust_home'),
    path(r'<pk>/updatecustomer/',UpdateCustomer.as_view(),name='update_cus'),
    path(r'delete/(?P<pk>[0-9]+)/$',DeleteCustomer.as_view(),name='delete_cus'),
    path(r'login/',LoginView.as_view(),name='login'),
    path(r'logout/', auth_views.LogoutView.as_view(), name='logout'),
    

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)