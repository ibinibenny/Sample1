from django.contrib import admin
from .models import ColdCoffee

admin.site.register(ColdCoffee)
