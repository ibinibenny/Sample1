from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings

from trainer.views import TrainerRegister,Trainerlist,UpdateTrainer,DeleteTrainer,LoginView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path(r'register/',TrainerRegister.as_view(),name='trainer_reg'),
    path(r'trainerlist/',Trainerlist.as_view(),name='trainer_list'),
    path(r'<pk>/updatetrainer/',UpdateTrainer.as_view(),name='update_trainer'),
    path(r'delete/(?P<pk>[0-9]+)/$',DeleteTrainer.as_view(),name='delete_trainer'),
    path(r'login/',LoginView.as_view(),name='login_t'),
    path(r'logout/', auth_views.LogoutView.as_view(), name='logout')
    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)